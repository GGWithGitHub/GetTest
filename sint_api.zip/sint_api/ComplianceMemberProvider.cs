﻿using FirebaseAdmin.Messaging;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using Sint.Core.CommonClass;
using Sint.Core.Helper;
using Sint.Core.Interface;
using Sint.Core.ViewModels;
using Sint.Provider.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Sint.Core.Enums.DeviceEnum;

namespace Sint.Provider
{
    public class ComplianceMemberProvider : IComplianceMember
    {
        private readonly IUnitOfWork _unitOfWork;

        public ComplianceMemberProvider(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task<MemberAtMachineLookupDTOViewModel> FindmemberByMachineId(string MachineId)
        {
            var serr = string.Empty;
            var memberInfo = CompAPI.NMFunctions.FindmemberByMachineId(MachineId,ref serr);

            var responseModel = new MemberAtMachineLookupDTOViewModel()
            {
                MemberId = memberInfo?.MemberId,
                MemberName = memberInfo?.MemberName,
                MachineId = memberInfo?.MachineId,
                Status = serr
            };

            return responseModel;
        }

        public async Task<MemberAtMachineLookupDTOViewModel> FindmachineByMemberId(string MemberId)
        {
            var serr = string.Empty;
            var memberInfo = CompAPI.NMFunctions.FindmachineByMemberId(MemberId, ref serr);

            var responseModel = new MemberAtMachineLookupDTOViewModel()
            {
                MemberId = memberInfo?.MemberId,
                MemberName = memberInfo?.MemberName,
                MachineId = memberInfo?.MachineId,
                Status = serr
            };

            return responseModel;
        }
        public async Task<List<ComplianceMemberAlertsDTOViewModel>> GetComplianceMemberAlerts(ComplianceMemberAlertsRequestModel requestModel)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@MemberId", requestModel.MemberId),
                //new SqlParameter("@StartDate", DateTime.Now.AddMonths(-1)),
                new SqlParameter("@StartDate", requestModel.StartDate),
                new SqlParameter("@IncludeAml",requestModel.IncludeAml)
            };
            var datatable = (await (_unitOfWork.ExecuteStoredProcedureAndReturnDatatable("sp_Compliance_MemberAlerts", parameters.ToArray())));
            var list = new List<ComplianceMemberAlertsDTOViewModel>();
            if (datatable != null && datatable.Rows.Count > 0)
            {
                for (int i = 0; i < datatable.Rows.Count; i++)
                {
                    var row = datatable.Rows[i];

                    list.Add(new ComplianceMemberAlertsDTOViewModel
                    {
                        NotName = Convert.ToString(row["NotName"]),
                        MachineId = row["MachineId"] == DBNull.Value ? null : Convert.ToInt32(row["MachineId"]),
                        MemberId = Convert.ToString(row["MemberId"])
                    });
                }
            }
            return list;
        }

        public async Task<List<GetBehaviourTypesDTOViewModel>> GetBehaviourTypes()
        {
            var serr = string.Empty;
            var behaviourTypeList = CompAPI.NMFunctions.GetBehaviourTypes(ref serr);

            var list = new List<GetBehaviourTypesDTOViewModel>();

            foreach (var row in behaviourTypeList)
            {
                list.Add(new GetBehaviourTypesDTOViewModel
                {
                    CompBehaviourTypeID = row.ID,
                    TypeName = row.SName
                });
            }

            return list;
        }

        public async Task<List<GetBehavioursDTOViewModel>> GetBehaviours(int behaviourTypeID)
        {
            var serr = string.Empty;
            var behaviours = CompAPI.NMFunctions.GetBehavioursFromType(behaviourTypeID, ref serr);
            var list = new List<GetBehavioursDTOViewModel>();

            foreach (var behaviour in behaviours)
            {
                list.Add(new GetBehavioursDTOViewModel
                {
                    CompBehaviourID = behaviour.ID,
                    SName = behaviour.SName
                });
            }

            return list;
        }

        public async Task<List<GetAssessmentTypesDTOViewModel>> GetAssessmentTypes()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();

            var datatable = await _unitOfWork.ExecuteStoredProcedureAndReturnDatatable("sp_Comp_GetAssessmentTypes", parameters.ToArray());

            var list = new List<GetAssessmentTypesDTOViewModel>();

            if (datatable != null && datatable.Rows.Count > 0)
            {
                foreach (DataRow row in datatable.Rows)
                {
                    list.Add(new GetAssessmentTypesDTOViewModel
                    {
                        CompAssesmentTypeID = Convert.ToInt32(row["CompAssesmentType _ID"]),
                        SName = Convert.ToString(row["AssessmentTypeName"])
                    });
                }
            }

            return list;
        }

        public async Task<ComplianceLocationDTOViewModel> GetComplianceLocation(string NFCTagId)
        {
            var serr = string.Empty;
            var location = CompAPI.NMFunctions.GetLocationByNFCTag(NFCTagId);

            return new ComplianceLocationDTOViewModel
            {
                SiteLocation_ID = location.ID,
                SName = location.SName,
                Status = location.ErrorStatus
            };
        }

        public async Task<List<ComplianceLocationDTOViewModel>> GetComplianceLocations()
        {
            
            var serr = string.Empty;
            var locations = CompAPI.NMFunctions.GetLocations(ref serr);

            var list = new List<ComplianceLocationDTOViewModel>();

            foreach (var location in locations)
            {
                list.Add(new ComplianceLocationDTOViewModel
                {
                    SiteLocation_ID = location.ID,
                    SName = location.SName,
                    Status = location.ErrorStatus
                });
            }

            return list;
        }

        public async Task<List<ComplianceMemberAlertHistoryModel>> GetMemberAlertHistory(string memberId)
        {
            var serr = string.Empty;
            var alertHistoryList = CompAPI.NMFunctions.GetMemberAlertHistory(memberId, ref serr);

            var list = new List<ComplianceMemberAlertHistoryModel>();

            foreach (var alertHistory in alertHistoryList)
            {
                list.Add(new ComplianceMemberAlertHistoryModel
                {
                    AlertData = alertHistory.AlertData,
                    AlertDateTime = alertHistory.AlertDateTime,
                    AlertType = alertHistory.AlertType,
                    Status = serr,
                    CompIncindentID = alertHistory.CompIncindent_ID,
                    HasImage = alertHistory.HasImage
                });
            }

            return list;
        }

        public async Task<ResponseModel> ComplianceSubmitMachineEvent(AssessmentRequest assessmentRequest)
        {
            try
            {
                if (!Enum.TryParse<AssessmentAction>(assessmentRequest.Action, out var assessmentAction))
                {
                    return new ResponseModel() { serror = $"Invalid assessment action. Valid action are: {string.Join(", ", Enum.GetNames(typeof(AssessmentAction)))}" };
                }

                var serr = string.Empty;
                string jsonString = ConvertModelToJsonInCamelCase(assessmentRequest);

                CompAPI.NMFunctions.MachineIncident.AssessmentComplete(jsonString, ref serr);

                return new ResponseModel() { serror = serr };
            }
            catch (Exception ex)
            {
                return new ResponseModel() { serror = ex.Message };
            }
        }

        public async Task<ResponseModel> ComplianceSubmitThirdPartyEvent(ComplianceSubmitThirdPartyEventViewModel complianceSubmitThirdPartyEventViewModel)
        {
            try
            {
                if (!Enum.TryParse<AssessmentAction>(complianceSubmitThirdPartyEventViewModel.Action, out var assessmentAction))
                {
                    return new ResponseModel() { serror = $"Invalid assessment action. Valid action are: {string.Join(", ", Enum.GetNames(typeof(AssessmentAction)))}" };
                }

                var serr = string.Empty;
                string jsonString = ConvertModelToJsonInCamelCase(complianceSubmitThirdPartyEventViewModel);
                CompAPI.NMFunctions.ThirdPartyIncident.AssessmentComplete(jsonString, ref serr);
                return new ResponseModel() { serror = serr };
            }
            catch (Exception ex)
            {
                return new ResponseModel() { serror = ex.Message };
            }
        }

        public async Task<ResponseModel> ComplianceSubmitVenueEvent(ComplianceSubmitVenueEventViewModel submitVenueEventRequest, byte[] photo)
        {
            try
            {
                if (!Enum.TryParse<AssessmentAction>(submitVenueEventRequest.Action, out var assessmentAction))
                {
                    return new ResponseModel() { serror = $"Invalid assessment action. Valid action are: {string.Join(", ", Enum.GetNames(typeof(AssessmentAction)))}" };
                }

                var serr = string.Empty;
                
                var jsonString = ConvertModelToJsonInCamelCase(submitVenueEventRequest);

                CompAPI.NMFunctions.VenueIncident.AssessmentComplete(jsonString, photo, ref serr);

                return new ResponseModel() { serror = serr };

            }
            catch (Exception ex)
            {
                return new ResponseModel() { serror = ex.Message };
            }
        }

        public async Task<ResponseModel> SubmitCompliance(SubmitComplianceModel submitCompliance, byte[] photo)
        {
            try
            {
                var serr = string.Empty;

                var jsonString = ConvertModelToJsonInCamelCase(submitCompliance);

                CompAPI.NMFunctions.ComplianceCheck.AssessmentComplete(jsonString, photo, ref serr);

                return new ResponseModel() { serror = serr };
            }
            catch (Exception ex)
            {
                return new ResponseModel() { serror = ex.Message };
            }

        }

        public async Task<ComplianceImageResponseModel> GetComplianceImage(long compIncindentID)
        {
            try
            {
                var serr = string.Empty;
                var imageUrl = CompAPI.NMFunctions.GetComplianceImage(compIncindentID, ref serr);
                return new ComplianceImageResponseModel() { serror = serr, ImageData = imageUrl  };
            }
            catch (Exception ex)
            {
                return new ComplianceImageResponseModel() { serror = ex.Message };
            }
        }

        public async Task<ResponseModel> ProcessVisitorEventAsync(VisitorRequest request)
        {
            try
            {
                AddLog("ProcessVisitorEventAsync started");
                var serr = string.Empty;
                return new ResponseModel() { serror = serr };
            }
            catch (Exception ex)
            {
                return new ResponseModel() { serror = ex.Message };
            }
        }

        private string ConvertModelToJsonInCamelCase(object model) {
            var jsonString = JsonConvert.SerializeObject(
                            model,
                            new JsonSerializerSettings
                            {
                                ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver(),
                                Formatting = Formatting.Indented // optional, for pretty print
                            });
            return jsonString;
        }

        private void AddLog(string message)
        {
            var directoryPath = Directory.GetCurrentDirectory();
            var logFilePath = Path.Combine(directoryPath, $"TestLog_{DateTime.Now.ToString("MM-dd-yyyy")}.txt");
            File.AppendAllText(logFilePath, $"{DateTime.Now}: {message} {Environment.NewLine}");
        }

    }
}
