﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sint.Core.ViewModels
{
    public class ResponseModel
    {
        public string serror { get; set; }
    }

    public class CallAcknowledgeResponseModel
    {
        public string serror { get; set; }
        public int acknowledgeResponse { get; set; }
    }

    public class NFCCloseRequestResponseModel
    {
        public string serror { get; set; }
        public int closeCallResponse { get; set; }
    }
}
