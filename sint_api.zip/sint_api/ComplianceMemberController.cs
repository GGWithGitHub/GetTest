﻿using FirebaseAdmin.Messaging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sint.Core.Exceptions;
using Sint.Core.Helper;
using Sint.Core.Interface;
using Sint.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Sint.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComplianceMemberController : ControllerBase
    {
        private readonly IComplianceMember _complianceMemberService;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ComplianceMemberController(IComplianceMember complianceMemberService, IWebHostEnvironment webHostEnvironment)
        {
            _complianceMemberService = complianceMemberService;
            _webHostEnvironment = webHostEnvironment;
        }

        /// <summary>
        /// Get Machine by memberId
        /// </summary>
        /// <returns></returns>
        [HttpGet("MachineLookup/{memberId}")]
        [ProducesResponseType(typeof(MemberAtMachineLookupDTOViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> MachineLookup(string memberId)
        {
            try
            {
                return Ok(await _complianceMemberService.FindmachineByMemberId(memberId).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// Get Member by machineId
        /// </summary>
        /// <param name="machineId"></param>
        /// <returns></returns>
        [HttpGet("MemberLookup/{machineId}")]
        [ProducesResponseType(typeof(MemberAtMachineLookupDTOViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> MemberLookup(string machineId)
        {
            try
            {
                return Ok(await _complianceMemberService.FindmemberByMachineId(machineId).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        ///  Get ComplianceMember Alerts
        /// </summary>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        [HttpPost("Alerts")]
        [ProducesResponseType(typeof(List<ComplianceMemberAlertsDTOViewModel>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetComplianceMemberAlerts(ComplianceMemberAlertsRequestModel requestModel)
        {
            try
            {
                return Ok(await _complianceMemberService.GetComplianceMemberAlerts(requestModel).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        ///  Get Behaviour Types
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet("ComplianceBehaviourTypes")]
        [ProducesResponseType(typeof(List<GetBehaviourTypesDTOViewModel>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ComplianceBehaviourTypes()
        {
            try
            {
                return Ok(await _complianceMemberService.GetBehaviourTypes().ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        ///  Get Behaviours
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet("ComplianceBehaviours/{behaviourTypeId}")]
        [ProducesResponseType(typeof(List<GetBehavioursDTOViewModel>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ComplianceBehaviours(int behaviourTypeId)
        {
            try
            {
                return Ok(await _complianceMemberService.GetBehaviours(behaviourTypeId).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        ///  Get Assessment Types
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet("GetAssessmentTypes")]
        [ProducesResponseType(typeof(List<GetAssessmentTypesDTOViewModel>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAssessmentTypes()
        {
            try
            {
                return Ok(await _complianceMemberService.GetAssessmentTypes().ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// Get Compliance Location by nfctagId
        /// </summary>
        /// <param name="nfctagId"></param>
        /// <returns></returns>
        [HttpGet("ComplianceLocation/{nfctagId}")]
        [ProducesResponseType(typeof(ComplianceLocationDTOViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ComplianceLocation(string nfctagId)
        {
            try
            {
                return Ok(await _complianceMemberService.GetComplianceLocation(nfctagId).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// Get Compliance Locations
        /// </summary>
        /// <returns></returns>
        [HttpGet("ComplianceLocations")]
        [ProducesResponseType(typeof(ComplianceLocationDTOViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ComplianceLocations()
        {
            try
            {
                return Ok(await _complianceMemberService.GetComplianceLocations().ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// Get Member Alert History
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        [HttpGet("MemberAlertHistory/{memberId}")]
        [ProducesResponseType(typeof(ComplianceMemberAlertHistoryModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetMemberAlertHistory(string memberId)
        {
            try
            {
                return Ok(await _complianceMemberService.GetMemberAlertHistory(memberId).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// Submit Machine Event
        /// </summary>
        /// <param name="complianceSubmitMachineEventViewModel"></param>
        /// <returns></returns>
        [ProducesResponseType(typeof(ResponseModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        [HttpPost("SubmitMachineEvent")]
        public async Task<IActionResult> SubmitMachineEvent(AssessmentRequest complianceSubmitMachineEventViewModel)
        {
            try
            {
                return Ok(await _complianceMemberService.ComplianceSubmitMachineEvent(complianceSubmitMachineEventViewModel).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        [ProducesResponseType(typeof(ResponseModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        [HttpPost("SubmitThirdPartyEvent")]
        public async Task<IActionResult> SubmitThirdPartyEvent(ComplianceSubmitThirdPartyEventViewModel complianceSubmitThirdPartyEventViewModel)
        {
            try
            {
                return Ok(await _complianceMemberService.ComplianceSubmitThirdPartyEvent(complianceSubmitThirdPartyEventViewModel).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file"></param>
        /// <param name="complianceSubmitVenueEventViewModel"></param>
        /// <returns></returns>
        [ProducesResponseType(typeof(ResponseModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        [HttpPost("SubmitVenueEvent")]
        public async Task<IActionResult> SubmitVenueEvent([FromForm] ComplianceSubmitVenueEventViewModel complianceSubmitVenueEventViewModel,IFormFile file)
        {
            try
            {
                if (complianceSubmitVenueEventViewModel.NonmemberInfo != null && !complianceSubmitVenueEventViewModel.NonmemberInfo.Unknown.HasValue)
                {
                    complianceSubmitVenueEventViewModel.NonmemberInfo.Unknown = false;
                }

                string photoLocation = string.Empty;
                string baseUploadPath = "Upload/Compliance/VenueEvent"; // Define base upload path here
                //var file = complianceSubmitVenueEventViewModel.file;
                byte[] fileBytes = default;
                if (file != null && file.Length > 0)
                {
                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
                    var extension = Path.GetExtension(file.FileName);
                    if (!allowedExtensions.Contains(extension.ToLower()))
                    {
                        return BadRequest($"Invalid file type. Allowed file types are: {string.Join(", ", allowedExtensions)}");
                    }

                    using (var memoryStream = new MemoryStream())
                    {
                        await file.CopyToAsync(memoryStream);
                        fileBytes = memoryStream.ToArray();
                    }

                    //var uploadsFolderPath = Path.Combine(Directory.GetCurrentDirectory(), baseUploadPath);
                    //if (!Directory.Exists(uploadsFolderPath))
                    //{
                    //    Directory.CreateDirectory(uploadsFolderPath);
                    //}
                    //string fileName = $"{Guid.NewGuid()}_{file.FileName}";
                    //var fileFolderPath = Path.Combine(uploadsFolderPath, fileName);
                    //photoLocation = $"{baseUploadPath}/{fileName}";

                    //// Save the uploaded file to the server
                    //using (var fileStream = new FileStream(fileFolderPath, FileMode.Create))
                    //{
                    //    await file.CopyToAsync(fileStream);
                    //}
                }
                return Ok(await _complianceMemberService.ComplianceSubmitVenueEvent(complianceSubmitVenueEventViewModel, fileBytes).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        [ProducesResponseType(typeof(ResponseModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        [HttpPost("SubmitCompliance")]
        public async Task<IActionResult> SubmitCompliance([FromForm] SubmitComplianceModel submitCompliance, IFormFile UploadPhoto, IFormFile UploadAudio)
        {
            try
            {
                string imageLocation = string.Empty;
                string baseUploadPath = "Upload/SubmitCompliance";
                byte[] fileBytes = default;
                
                if (UploadAudio != null && UploadAudio.Length > 0)
                {
                    var allowedExtensions = new[] { ".mp3", ".wav", ".ogg", ".aac", ".flac", ".m4a" };
                    var extension = Path.GetExtension(UploadAudio.FileName);
                    if (!allowedExtensions.Contains(extension.ToLower()))
                    {
                        return BadRequest($"Invalid file type. Allowed file types are: {string.Join(", ", allowedExtensions)}");
                    }
                    using (var memoryStream = new MemoryStream())
                    {
                        await UploadAudio.CopyToAsync(memoryStream);
                        fileBytes = memoryStream.ToArray();
                    }
                }

                if (UploadPhoto != null && UploadPhoto.Length > 0)
                {
                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
                    var extension = Path.GetExtension(UploadPhoto.FileName);
                    if (!allowedExtensions.Contains(extension.ToLower()))
                    {
                        return BadRequest($"Invalid file type. Allowed file types are: {string.Join(", ", allowedExtensions)}");
                    }
                    using (var memoryStream = new MemoryStream())
                    {
                        await UploadPhoto.CopyToAsync(memoryStream);
                        fileBytes = memoryStream.ToArray();
                    }
                }

                return Ok(await _complianceMemberService.SubmitCompliance(submitCompliance, fileBytes).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// Get Compliance Image
        /// </summary>
        /// <param name="compIncindentID"></param>
        /// <returns></returns>
        [HttpGet("GetComplianceImage")]
        [ProducesResponseType(typeof(ComplianceImageResponseModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetComplianceImage(long compIncindentID)
        {
            try
            {
                return Ok(await _complianceMemberService.GetComplianceImage(compIncindentID).ConfigureAwait(false));
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [ProducesResponseType(typeof(ResponseModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(HttpResponseErrorModel), StatusCodes.Status400BadRequest)]
        [HttpPost("SubmitVisitorEvent")]
        public async Task<IActionResult> SubmitVisitorEvent([FromBody] VisitorRequest request)
        {
            if (request == null)
            {
                return BadRequest(ResponseBuilder.HandleResponse(StatusCodes.Status400BadRequest, "Invalid request body"));
            }

            try
            {
                var result = await _complianceMemberService.ProcessVisitorEventAsync(request).ConfigureAwait(false);

                return Ok(result);
            }
            catch (NotFoundException ex)
            {
                return NotFound(ResponseBuilder.HandleResponse(StatusCodes.Status404NotFound, ex.Message));
            }
        }
    }
}
