﻿using Sint.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sint.Core.Interface
{
    public interface IComplianceMember
    {
        Task<MemberAtMachineLookupDTOViewModel> FindmemberByMachineId(string MachineId);
        Task<MemberAtMachineLookupDTOViewModel> FindmachineByMemberId(string MemberId);
        Task<List<ComplianceMemberAlertsDTOViewModel>> GetComplianceMemberAlerts(ComplianceMemberAlertsRequestModel requestModel);

        Task<List<GetBehaviourTypesDTOViewModel>> GetBehaviourTypes();
        Task<List<GetBehavioursDTOViewModel>> GetBehaviours(int BehaviourTypeID);
        Task<List<GetAssessmentTypesDTOViewModel>> GetAssessmentTypes();

        Task<ComplianceLocationDTOViewModel> GetComplianceLocation(string NFCTagId);
        Task<List<ComplianceLocationDTOViewModel>> GetComplianceLocations();
        Task<List<ComplianceMemberAlertHistoryModel>> GetMemberAlertHistory(string memberId);
        Task<ResponseModel> ComplianceSubmitMachineEvent(AssessmentRequest complianceSubmitMachineEventViewModel);
        Task<ResponseModel> ComplianceSubmitThirdPartyEvent(ComplianceSubmitThirdPartyEventViewModel complianceSubmitThirdPartyEventViewModel);
        Task<ResponseModel> ComplianceSubmitVenueEvent(ComplianceSubmitVenueEventViewModel complianceSubmitVenueEventViewModel, byte[] photo);
        Task<ResponseModel> SubmitCompliance(SubmitComplianceModel submitCompliance, byte[] photo);
        Task<ComplianceImageResponseModel> GetComplianceImage(long compIncindentID);

        Task<ResponseModel> ProcessVisitorEventAsync(VisitorRequest request);
    }
}
