import { TempConvertorPipe } from './temp-convertor.pipe';

describe('TempConvertorPipe', () => {
  it('create an instance', () => {
    const pipe = new TempConvertorPipe();
    expect(pipe).toBeTruthy();
  });
});
