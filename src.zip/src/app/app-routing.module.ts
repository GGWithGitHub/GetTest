import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent } from './_components/auth/register/register.component';
import { LoginComponent } from './_components/auth/login/login.component';
import { HomeComponent } from './_components/home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { BoardUserComponent } from './board-user/board-user.component';
import { BoardAdminComponent } from './board-admin/board-admin.component';
import { GetAllProductComponent } from './_components/product/get-all-product/get-all-product.component';
import { AddEditProductComponent } from './_components/product/add-edit-product/add-edit-product.component';
import { TutorialsListComponent } from './_components/tutorial/tutorials-list/tutorials-list.component';
import { TutorialDetailsComponent } from './_components/tutorial/tutorial-details/tutorial-details.component';
import { AddTutorialComponent } from './_components/tutorial/add-tutorial/add-tutorial.component';
import { AuthorizationGuard } from './_guard/authorization.guard';
import { NotAuthorizedComponent } from './_components/auth/not-authorized/not-authorized.component';
import { ReactiveformComponent } from './_components/reactiveform/reactiveform.component';
import { DatabindComponent } from './_components/databind/databind.component';
import { DirectivesComponent } from './_components/directives/directives.component';
import { PipesComponent } from './_components/pipes/pipes.component';
import { ComponentCommunicationComponent } from './_components/component-communication/component-communication.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'userBoard', component: BoardUserComponent, canActivate: [AuthorizationGuard] },
  { path: 'adminBoard', component: BoardAdminComponent, canActivate: [AuthorizationGuard] },
  { path: 'getAllProduct',component:GetAllProductComponent},
  { path: 'addEditProduct/:productId',component:AddEditProductComponent},
  { path: 'tutorials', component: TutorialsListComponent },
  { path: 'tutorials/:id', component: TutorialDetailsComponent },
  { path: 'add', component: AddTutorialComponent },
  { path: 'not-authorized', component: NotAuthorizedComponent },
  { path: 'reactiveForm', component: ReactiveformComponent },
  { path: 'dataBind', component: DatabindComponent },
  { path: 'directives', component: DirectivesComponent },
  { path: 'pipes', component: PipesComponent },
  { path: 'compComm', component:ComponentCommunicationComponent },
  
  { path: '', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
