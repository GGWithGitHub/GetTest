import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Tutorial } from '../model/tutorial.model';
import { ApiResponse } from '../interfaces/api-response';

const baseUrl = 'https://localhost:44344';

@Injectable({
  providedIn: 'root'
})
export class TutorialService {

  constructor(private http: HttpClient) { }

  getAll(): Observable<ApiResponse<Tutorial[]>> {
    return this.http.get<ApiResponse<Tutorial[]>>(`${baseUrl}/api/tutorial/getTutorials`);
  }

  findTutorialByTitle(title:any): Observable<ApiResponse<Tutorial[]>> {
    return this.http.get<ApiResponse<Tutorial[]>>(`${baseUrl}/api/tutorial/getTutorialsByTitle?title=${title}`);
  }

  get(id: any): Observable<ApiResponse<Tutorial>> {
    return this.http.get<ApiResponse<Tutorial>>(`${baseUrl}/api/tutorial/getTutorial/${id}`);
  }

  create(data: any): Observable<ApiResponse<Tutorial>> {
    return this.http.post<ApiResponse<Tutorial>>(`${baseUrl}/api/tutorial/createTutorial`, data);
  }

  update(id: any, data: any): Observable<ApiResponse<boolean>> {
    return this.http.put<ApiResponse<boolean>>(`${baseUrl}/api/tutorial/updateTutorial/${id}`, data);
  }

  delete(id: any): Observable<ApiResponse<boolean>> {
    return this.http.delete<ApiResponse<boolean>>(`${baseUrl}/api/tutorial/deleteTutorial/${id}`);
  }

  deleteAll(): Observable<ApiResponse<boolean>> {
    return this.http.delete<ApiResponse<boolean>>(`${baseUrl}/api/tutorial/deleteAllTutorial`);
  }
}
