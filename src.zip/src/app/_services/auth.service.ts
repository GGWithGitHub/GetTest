import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // added manually
import { Observable, of } from 'rxjs'; // added manually
import { RegistrationRequestModel } from '../model/registration-request-model';
import { ApiResponse } from '../interfaces/api-response';
import { LoginRequest } from '../model/login-request.model';
import { LoginResponse } from '../model/login-response.model';

const baseUrl = 'https://localhost:44344';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(model:LoginRequest): Observable<ApiResponse<LoginResponse>> {
    //return this.http.post<ApiResponse<LoginResponse>>(`${baseUrl}/api/auth/login`, model);

    // Hardcoded check for login credentials
    if (model.userName === 'testuser1@gmail.com' && model.password === 'Testuser@12') 
    {
      const loginResponse: LoginResponse = {
        user: {
          id: '123',
          email: 'testuser1@gmail.com',
          name: 'Test User',
          phoneNumber: '123-456-7890',
          roles: ['User']
        },
        token: 'fake-jwt-user-token' 
      };
      const response: ApiResponse<LoginResponse> = {
        isSuccess: true,
        message: 'Login successful',
        result: loginResponse
      };
      return of(response); // Return an observable with the simulated response
    } 
    else if(model.userName === 'testadmin1@gmail.com' && model.password === 'Testuser@12')
    {
      const loginResponse: LoginResponse = {
        user: {
          id: '124',
          email: 'testadmin1@gmail.com',
          name: 'Test Admin',
          phoneNumber: '823-456-7890',
          roles: ['Admin']
        },
        token: 'fake-jwt-admin-token' 
      };
      const response: ApiResponse<LoginResponse> = {
        isSuccess: true,
        message: 'Login successful',
        result: loginResponse
      };
      return of(response); // Return an observable with the simulated response
    }
    else 
    {
      const errorResponse: ApiResponse<LoginResponse> = {
        isSuccess: false,
        message: 'Invalid credentials',
        result: {} as LoginResponse
      };
      return of(errorResponse); // Return observable with error response
    }
  
  }

  register(model: RegistrationRequestModel): Observable<ApiResponse<boolean>> {
    return this.http.post<ApiResponse<boolean>>(`${baseUrl}/api/auth/register`, model);
  }
}
