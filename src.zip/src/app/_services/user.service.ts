import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResponse } from '../interfaces/api-response';

const baseUrl = 'https://localhost:44344';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  getUserBoard(): Observable<ApiResponse<boolean>> {
    return this.http.get<ApiResponse<boolean>>(baseUrl + '/api/user/userBoard');
  }

  getAdminBoard(): Observable<ApiResponse<boolean>> {
    return this.http.get<ApiResponse<boolean>>(baseUrl + '/api/user/adminBoard');
  }
}
