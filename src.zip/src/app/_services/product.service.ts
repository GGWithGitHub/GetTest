import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // added manually
import { Observable } from 'rxjs'; // added manually

const BASE_API = 'http://localhost:8080/api/auth/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  getProductList(): Observable<any>{
    return this.http.get(BASE_API + 'getAllProduct', httpOptions);
  }

  getProduct(productId:number): Observable<any>{
    return this.http.get(BASE_API + 'getProduct?productId='+productId, httpOptions);
  }

  addEditProduct(product:Product): Observable<any>{
    debugger
    if(product.productId){ //edit
      return this.http.post(BASE_API + 'editProduct', { product }, httpOptions);
    }
    else{ //add
      return this.http.post(BASE_API + 'addProduct', { product }, httpOptions);
    }
  }

  deleteProduct(productId:number):Observable<any>{
    return this.http.get(BASE_API + 'deleteProduct?productId='+productId, httpOptions);
  }
}
