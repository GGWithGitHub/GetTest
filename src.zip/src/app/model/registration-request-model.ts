export class RegistrationRequestModel {
    email?: string;
    name?: string;
    password?: string;
    phoneNumber?:string;
}
