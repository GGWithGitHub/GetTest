import { LoginResponse } from './login-response.model';

describe('LoginResponse', () => {
  it('should create an instance', () => {
    expect(new LoginResponse()).toBeTruthy();
  });
});
