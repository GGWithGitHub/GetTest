export class Customer {
    customerNo?: number;
    name?:string ;
    address?:string;
    city?:string;
    state?:string;
    country?:string;
   
  }