import { RegistrationRequestModel } from './registration-request-model';

describe('RegistrationRequestModel', () => {
  it('should create an instance', () => {
    expect(new RegistrationRequestModel()).toBeTruthy();
  });
});
