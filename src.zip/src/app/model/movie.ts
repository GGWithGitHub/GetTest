export class Movie {
    title? : string;
    director? : string;
    cast? : string;
    releaseDate? : string;
  }