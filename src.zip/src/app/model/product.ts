export interface Product {
    productId:number,
    productName:string,
    productDesc:string,
    productPrice:number,
    productStock:number
}
