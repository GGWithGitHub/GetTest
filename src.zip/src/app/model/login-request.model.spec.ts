import { LoginRequest } from './login-request.model';

describe('LoginRequest', () => {
  it('should create an instance', () => {
    expect(new LoginRequest()).toBeTruthy();
  });
});
