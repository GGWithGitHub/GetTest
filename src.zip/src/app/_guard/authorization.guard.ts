import { CanActivateFn, Router } from '@angular/router';
import {inject} from "@angular/core";
import { TokenStorageService } from '../_services/token-storage.service';

export const AuthorizationGuard: CanActivateFn = (route, state) => {
  const tokenStorageService = inject(TokenStorageService); // Injecting AuthService
  const router = inject(Router); // Injecting Router
  const routePath = route.routeConfig?.path;

  const token = tokenStorageService.getToken();
  const currentUserRoles = tokenStorageService.getUser()?.roles || [];

  if(!token){
    router.navigate(['/login']);
    return false;
  }

  // Role-based authorization logic
  if (currentUserRoles.includes('Admin')) {
    // Admin-specific access check
    if (isAdminAllowedToAccess(routePath)) {
      return true;
    } 
    else {
      router.navigate(['/not-authorized']);
      return false;
    }
  } 
  else if (currentUserRoles.includes('User')) {
    // User-specific access check
    if (isUserAllowedToAccess(routePath)) {
      return true;
    } 
    else {
      router.navigate(['/not-authorized']);
      return false;
    }
  } 
  else {
    // If no matching role, redirect to not-authorized
    router.navigate(['/not-authorized']);
    return false;
  }
};

// Helper method to check if a route is allowed for a 'Admin'
function isAdminAllowedToAccess(path: string | undefined): boolean {
  const allowedAdminPages = ['adminBoard','userBoard'];  // Example admin,user pages
  return allowedAdminPages.includes(path || '');
}

// Helper method to check if a route is allowed for a 'User'
function isUserAllowedToAccess(path: string | undefined): boolean {
  const allowedUserPages = ['userBoard'];  // Example user pages
  return allowedUserPages.includes(path || '');
}


