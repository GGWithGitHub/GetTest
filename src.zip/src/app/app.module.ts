import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; // added FormsModule manually
import { HttpClientModule } from '@angular/common/http'; // added HttpClientModule manually
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './_components/auth/login/login.component';
import { RegisterComponent } from './_components/auth/register/register.component';

import { authInterceptorProviders } from './_helpers/auth.interceptor';
import { HomeComponent } from './_components/home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { BoardAdminComponent } from './board-admin/board-admin.component';
import { BoardUserComponent } from './board-user/board-user.component';
import { AddEditProductComponent } from './_components/product/add-edit-product/add-edit-product.component';
import { GetAllProductComponent } from './_components/product/get-all-product/get-all-product.component';
import { AddTutorialComponent } from './_components/tutorial/add-tutorial/add-tutorial.component';
import { TutorialDetailsComponent } from './_components/tutorial/tutorial-details/tutorial-details.component';
import { TutorialsListComponent } from './_components/tutorial/tutorials-list/tutorials-list.component';
import { NotAuthorizedComponent } from './_components/auth/not-authorized/not-authorized.component';
import { ReactiveformComponent } from './_components/reactiveform/reactiveform.component';
import { DatabindComponent } from './_components/databind/databind.component';
import { CustomerListComponent } from './_components/customer-list/customer-list.component';
import { DirectivesComponent } from './_components/directives/directives.component';
import { PipesComponent } from './_components/pipes/pipes.component';
import { TempConvertorPipe } from './_pipes/temp-convertor.pipe';
import { ComponentCommunicationComponent } from './_components/component-communication/component-communication.component';
import { ChildComponentComponent } from './_components/component-communication/child-component/child-component.component';
import { ChildComponent2Component } from './_components/component-communication/child-component2/child-component2.component'; // added authInterceptorProviders manually

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    ProfileComponent,
    BoardAdminComponent,
    BoardUserComponent,
    AddEditProductComponent,
    GetAllProductComponent,
    AddTutorialComponent,
    TutorialDetailsComponent,
    TutorialsListComponent,
    NotAuthorizedComponent,
    ReactiveformComponent,
    DatabindComponent,
    CustomerListComponent,
    DirectivesComponent,
    PipesComponent,
    TempConvertorPipe,
    ComponentCommunicationComponent,
    ChildComponentComponent,
    ChildComponent2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, // added FormsModule manually
    HttpClientModule, // added HttpClientModule manually
    ReactiveFormsModule
  ],
  providers: [
    authInterceptorProviders // added authInterceptorProviders manually
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
