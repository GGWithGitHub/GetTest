import { Component } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent {
  toDate: Date = new Date(); 

  msg: string= 'Welcome to Angular';

  per: number= .7414;

  cur: number= 175;

  counter:number = 0;

  celcius: number = 0;
  fahrenheit: number = 0; 

  obsValue = new Observable((observer) => {
    setTimeout(() => { 
      observer.next(90000) 
    }, 1000);
  })
}
