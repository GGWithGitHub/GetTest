import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/_services/product.service';
import { ActivatedRoute } from '@angular/router';

import { Product } from 'src/app/model/product';

@Component({
  selector: 'app-add-edit-product',
  templateUrl: './add-edit-product.component.html',
  styleUrls: ['./add-edit-product.component.css']
})
export class AddEditProductComponent implements OnInit {

  constructor(private productService:ProductService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.productService.getProduct(this.route.snapshot.params['id']).subscribe({
      next: data => {
        this.form = data;
      },
      error: err => {
        console.log(err);
      }
    });
  }

  form: Product = {
    productId: this.route.snapshot.params['productId'], 
    productName: '',
    productDesc: '',
    productPrice: 0,
    productStock: 0,
  };
  isSuccessful = false;
  isSubmitFailed = false;
  errorMessage = '';

  onSubmit(): void {
    debugger
    this.productService.addEditProduct(this.form).subscribe({
      next: data => {
        console.log(data);
        this.isSuccessful = true;
        this.isSubmitFailed = false;
      },
      error: err => {
        this.errorMessage = err.error.message;
        this.isSubmitFailed = true;
      }
    });
  }
}
