import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/_services/product.service';

import { Product } from 'src/app/model/product';

@Component({
  selector: 'app-get-all-product',
  templateUrl: './get-all-product.component.html',
  styleUrls: ['./get-all-product.component.css']
})
export class GetAllProductComponent implements OnInit {
  products:Product[] = [];

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.getAllProduct();
  }
  
  getAllProduct(): void {
    this.productService.getProductList().subscribe({
      next: data => {
        this.products = data;
      },
      error: err => {
        
      }
    });
  }

  deleteProduct(productId: any) {
    this.productService.deleteProduct(productId).subscribe({
      next: data => {
        this.getAllProduct();
      },
      error: err => {
        
      }
    });
  }
}
