import { Component, OnInit  } from '@angular/core';
import { AuthService } from '../../../_services/auth.service';
import { RegistrationRequestModel } from '../../../model/registration-request-model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form: any = {
    username: null,
    email: null,
    password: null,
    phone:null
  };
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
  }

  onSubmit(): void {
    var model: RegistrationRequestModel = new RegistrationRequestModel();
    model.name = this.form.username;
    model.email = this.form.email;
    model.password = this.form.password;
    model.phoneNumber = this.form.phone;

    this.authService.register(model).subscribe({
      next: (response) => {
        if (response.isSuccess) {
          this.isSuccessful = true;
          this.isSignUpFailed = false;
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (error) => {
        this.isSignUpFailed = true;
        this.errorMessage = 'An error occurred while registering.';
        console.error('Request failed:', error);
      }
    });
  }
}
