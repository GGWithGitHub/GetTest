import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../_services/auth.service';
import { TokenStorageService } from '../../../_services/token-storage.service';
import { LoginRequest } from '../../../model/login-request.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form: any = {
    username: null,
    password: null
  };
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];

  constructor(private authService: AuthService, 
              private tokenStorage: TokenStorageService,
              private router: Router) { }

  ngOnInit(): void {
    if (this.tokenStorage.getToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorage.getUser().roles;
    }
  }

  onSubmit(): void {
    var model:LoginRequest = new LoginRequest();
    model.userName = this.form.username;
    model.password = this.form.password;
    
    this.authService.login(model).subscribe({
      next: (response) => {
        if (response.isSuccess) {
          this.tokenStorage.saveToken(response.result.token);
          this.tokenStorage.saveUser(response.result.user);
          this.isLoginFailed = false;
          this.isLoggedIn = true;
          this.roles = this.tokenStorage.getUser().roles;

          if(this.roles.includes('User')){
            this.router.navigate(['/userBoard']);
          }
          else if(this.roles.includes('Admin')){
            this.router.navigate(['/adminBoard']);
          }
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (error) => {
        this.isLoginFailed = true;
        this.errorMessage = 'An error occurred while login.';
        console.error('Request failed:', error);
      }
    });
  }

  reloadPage(): void {
    window.location.reload();
  }
}
