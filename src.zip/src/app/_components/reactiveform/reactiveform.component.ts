import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray, FormRecord } from '@angular/forms';
import { gte } from 'src/app/_validators/gte.validator';
import { Country } from 'src/app/model/country.model';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {

  public mainForm: FormRecord = new FormRecord<FormControl<string | null>>({});
  public designations: string[] = ['CEO', 'Manager', 'Supervisor'];
  newDesignation:string = "";

  constructor() {}

  ngOnInit() {
    this.designations.forEach((key) =>
      this.mainForm.addControl(key, new FormControl(''))
    );
  }

  contactForm = new FormGroup({
    firstname: new FormControl('',[Validators.required,Validators.minLength(10)]),
    lastname: new FormControl('',[Validators.required, Validators.maxLength(15), Validators.pattern("^[a-zA-Z]+$")]),
    email:new FormControl('',[Validators.email,Validators.required]),
    gender: new FormControl('',[Validators.required]),
    isMarried: new FormControl(false,[Validators.required]),
    country: new FormControl('',[Validators.required]),
    address:new FormGroup({
      city: new FormControl('',[Validators.required]),
      street: new FormControl('',[Validators.required]),
      pincode:new FormControl('',[Validators.required])
    }),
    numVal: new FormControl(0, [gte]),
    skills: new FormArray([
      new FormGroup({
        skill: new FormControl(''),
        exp: new FormControl('')
      })
    ]) ,
  })

  addDesignation() {
    this.designations.push(this.newDesignation);
    this.mainForm.addControl(this.newDesignation, new FormControl(''));
    this.newDesignation="";
  }

  removeDesignation(key:string) {
    this.mainForm.removeControl(key);

    this.designations = this.designations.filter(designation => designation !== key);
  }

  get firstname() {
    return this.contactForm?.get('firstname');
  } 
 
  get lastname() {
    return this.contactForm?.get('lastname');
  } 
 
  get email() {
    return this.contactForm?.get('email');
  } 
 
  get gender() {
    return this.contactForm?.get('gender');
  } 
 
  get isMarried() {
    return this.contactForm?.get('isMarried');
  } 
 
  get country() {
    return this.contactForm?.get('country');
  } 
 
  get city() {
    return this.contactForm?.get("address")?.get('city');
  } 
 
  get street() {
    return this.contactForm?.get("address")?.get('street');
  } 
 
  get pincode() {
    return this.contactForm?.get("address")?.get('pincode');
  }

  get numVal() {
    return this.contactForm?.get("numVal");
  }

  get skills() : FormArray {
    return this.contactForm.get("skills") as FormArray
  }

  countryList: Country[] = [
    new Country("1", "India"),
    new Country('2', 'USA'),
    new Country('3', 'England')
  ];

  newSkill(): FormGroup {
    return new FormGroup({
      skill: new FormControl(''),  // Wrap string in FormControl
      exp: new FormControl(''),    // Wrap string in FormControl
    });
  }
 
  addSkills() {
    this.skills.push(this.newSkill());
  }
 
  removeSkill(i:number) {
    this.skills.removeAt(i);
  }

  setDefault() {
    let contact = {
      firstname: "Sachin",
      lastname: "Tendulkar",
      email: "sachin@gmail.com",
      gender: "male",
      isMarried: true,
      country: "2",
      address: {
        city: "Mumbai",
        street: "Perry Cross Rd",
        pincode: "400050"
      },
      numVal:20,
      skills:[
        {
          skill: 'C#',  
          exp: '4',    
        }
      ]
    };
 
    this.contactForm.setValue(contact);
  }

  reset() {
    this.contactForm.reset();
  }

  onSubmit() {
    console.log(this.contactForm?.value);
  }
}
