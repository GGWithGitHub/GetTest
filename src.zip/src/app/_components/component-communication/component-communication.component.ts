import { Component, ViewChild } from '@angular/core';
import { ChildComponentComponent } from './child-component/child-component.component';
import { ChildComponent2Component } from './child-component2/child-component2.component';

@Component({
  selector: 'app-component-communication',
  templateUrl: './component-communication.component.html',
  styleUrls: ['./component-communication.component.css']
})
export class ComponentCommunicationComponent {
  Counter = 5;
 
  increment() {
    this.Counter++;
  }
  decrement() {
    this.Counter--;
  }

  @ViewChild(ChildComponent2Component) child?: ChildComponent2Component;
 
  increment2() {
    this.child?.increment();
  }
 
  decrement2() {
    this.child?.decrement();
  }
}
