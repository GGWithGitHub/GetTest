import { Component,OnInit } from '@angular/core';
import { Tutorial } from 'src/app/model/tutorial.model';
import { TutorialService } from 'src/app/_services/tutorial.service';

@Component({
  selector: 'app-tutorials-list',
  templateUrl: './tutorials-list.component.html',
  styleUrls: ['./tutorials-list.component.css']
})
export class TutorialsListComponent implements OnInit {
  tutorials?: Tutorial[];
  currentTutorial: Tutorial = {};
  currentIndex = -1;
  title = '';
  errorMessage: string | null = null;

  constructor(private tutorialService: TutorialService) { }

  ngOnInit(): void {
    this.retrieveTutorials();
  }

  retrieveTutorials(): void {
    debugger
    this.tutorialService.getAll()
    .subscribe({
      next: (response) => {
        if (response.isSuccess) {
          this.tutorials = response.result;
          this.errorMessage = null;  // Clear any previous error messages
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (error) => {
        this.errorMessage = error.error.message;
        console.error('Request failed:', error);
      }
    });
  }

  refreshList(): void {
    this.retrieveTutorials();
    this.currentTutorial = {};
    this.tutorials=[];
    this.currentIndex = -1;
  }

  setActiveTutorial(tutorial: Tutorial, index: number): void {
    this.currentTutorial = tutorial;
    this.currentIndex = index;
  }

  removeAllTutorials(): void {
    this.tutorialService.deleteAll()
      .subscribe({
        next: (response) => {
          if (response.isSuccess) {
            this.refreshList();
          } else {
            this.errorMessage = response.message;
          }
        },
        error: (error) => {
          this.errorMessage = error.message;
          console.error('Request failed:', error);
        }

      });
  }

  searchTitle(): void {
    this.currentTutorial = {};
    this.currentIndex = -1;

    this.tutorialService.findTutorialByTitle(this.title)
      .subscribe({
        next: (response) => {
          if (response.isSuccess) {
            this.tutorials = response.result;
          } else {
            this.errorMessage = response.message;
          }
        },
        error: (error) => {
          this.errorMessage = error.message;
          console.error('Request failed:', error);
        }
      });
  }
}
