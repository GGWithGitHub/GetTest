import { Component, Input, OnInit } from '@angular/core';
import { Tutorial } from 'src/app/model/tutorial.model';
import { TutorialService } from 'src/app/_services/tutorial.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-tutorial-details',
  templateUrl: './tutorial-details.component.html',
  styleUrls: ['./tutorial-details.component.css']
})
export class TutorialDetailsComponent implements OnInit {
  @Input() viewMode = false;
  @Input() currentTutorial: Tutorial = {
    title: '',
    description: '',
    published: false
  };

  message = '';
  errorMessage: string | null = null;

  constructor(
    private tutorialService: TutorialService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    if (!this.viewMode) {
      this.message = '';
      this.getTutorial(this.route.snapshot.params["id"]);
    }
  }

  getTutorial(id: string): void {
      this.tutorialService.get(id)
      .subscribe({
        next: (response) => {
          if (response.isSuccess) {
            this.currentTutorial = response.result;
            this.errorMessage = null;  // Clear any previous error messages
          } else {
            this.errorMessage = response.message;
          }
        },
        error: (error) => {
          this.errorMessage = error.message;
          console.error('Request failed:', error);
        }
      });
  }

  updatePublished(status: boolean): void {
    const data = {
      title: this.currentTutorial.title,
      description: this.currentTutorial.description,
      published: status
    };

    this.message = '';

    this.tutorialService.update(this.currentTutorial.id, data)
      .subscribe({
        next: (response) => {
          if (response.isSuccess) {
            this.message = 'This tutorial was updated successfully!'
          } else {
            this.errorMessage = response.message;
          }
        },
        error: (error) => {
          this.errorMessage = error.message;
          console.error('Request failed:', error);
        }
      });
  }

  updateTutorial(): void {
    this.message = '';
    this.tutorialService.update(this.currentTutorial.id, this.currentTutorial)
      .subscribe({
        next: (response) => {
          if (response.isSuccess) {
            this.message = 'This tutorial was updated successfully!'
          } else {
            this.errorMessage = response.message;
          }
        },
        error: (error) => {
          this.errorMessage = error.message;
          console.error('Request failed:', error);
        }
      });
  }

  deleteTutorial(): void {
    this.tutorialService.delete(this.currentTutorial.id)
      .subscribe({
        next: (response) => {
          if (response.isSuccess) {
            this.router.navigate(['/tutorials']);
          } else {
            this.errorMessage = response.message;
          }
        },
        error: (error) => {
          this.errorMessage = error.message;
          console.error('Request failed:', error);
        }
      });
  }
}
