import { Component } from '@angular/core';

import { Tutorial } from 'src/app/model/tutorial.model';
import { TutorialService } from 'src/app/_services/tutorial.service';

@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.component.html',
  styleUrls: ['./add-tutorial.component.css']
})
export class AddTutorialComponent {
  tutorial: Tutorial = {
    title: '',
    description: '',
    published: false
  };
  submitted = false;
  errorMessage: string | null = null;

  constructor(private tutorialService: TutorialService) { }

  saveTutorial(): void {
    const data = {
      title: this.tutorial.title,
      description: this.tutorial.description
    };

    this.tutorialService.create(data)
    .subscribe({
      next: (response) => {
        if (response.isSuccess) {
          this.submitted = true;
          console.log('Tutorial: ', response.result);
        } else {
          this.errorMessage = response.message;
          console.error('Error: ', response.message);
        }
      },
      error: (error) => {
        this.errorMessage = 'An error occurred while adding tutorial.';
        console.error('Request failed:', error);
      }
    });
  }

  newTutorial(): void {
    this.submitted = false;
    this.tutorial = {
      title: '',
      description: '',
      published: false
    };
  }
}
