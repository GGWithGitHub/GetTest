import { Component } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  styleUrls: ['./databind.component.css']
})
export class DatabindComponent {
  firstName = 'Sachin';
  lastName = 'Tendulkar';

  isDisabled= true;

  cssVar: string = 'italics big';

  myValue="";

  sayHello(){
    alert("Hellooooo");
  }
}
