﻿using Azure;
using Azure.Core;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Office2016.Excel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using HstCopilot.Data;
using HstCopilot.Models;
using HstCopilot.ViewModels;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
//using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;

//using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using static iText.IO.Image.Jpeg2000ImageData;

namespace HstCopilot.Controllers
{
    [ApiController]
    [Route("api/iteration1")]
    [Authorize]
    public class Iteration1ApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<Iteration1ApiController> _logger;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly HttpClient _httpClient;
        private readonly AISettings _aISettings;
        private readonly IServiceScopeFactory _scopeFactory;

        private static readonly ConcurrentDictionary<string, JobStatus> _jobStatuses = new ConcurrentDictionary<string, JobStatus>();
        private static readonly Dictionary<string, string> LanguageMap = new(StringComparer.OrdinalIgnoreCase)
        {
            {"en-US", "English (US)"},
            {"es", "Spanish"},
            {"es-MX", "Spanish (Mexico)"},
            {"fr", "French"},
            {"de", "German"},
            {"it", "Italian"},
            {"pt", "Portuguese"},
            {"pt-BR", "Portuguese (Brazil)"},
            {"zh", "Chinese (Simplified)"},
            {"zh-TW", "Chinese (Traditional)"},
            {"ja", "Japanese"},
            {"ko", "Korean"},
            {"vi", "Vietnamese"},
            {"th", "Thai"},
            {"hi", "Hindi"},
            {"ru", "Russian"},
            {"ar", "Arabic"},
            {"tr", "Turkish"},
            {"pl", "Polish"},
            {"nl", "Dutch"},
            {"sv", "Swedish"},
            {"no", "Norwegian"},
            {"da", "Danish"},
            {"fi", "Finnish"},
            {"el", "Greek"},
            {"he", "Hebrew"},
            {"cs", "Czech"},
            {"hu", "Hungarian"},
            {"ro", "Romanian"},
            {"bg", "Bulgarian"},
            {"hr", "Croatian"},
            {"sk", "Slovak"},
            {"sl", "Slovenian"},
            {"et", "Estonian"},
            {"lv", "Latvian"},
            {"lt", "Lithuanian"},
            {"uk", "Ukrainian"},
            {"fa", "Persian/Farsi"},
            {"ur", "Urdu"},
            {"bn", "Bengali"},
            {"ta", "Tamil"},
            {"te", "Telugu"},
            {"mr", "Marathi"},
            {"gu", "Gujarati"},
            {"kn", "Kannada"},
            {"ml", "Malayalam"},
            {"pa", "Punjabi"},
            {"id", "Indonesian"},
            {"ms", "Malay"},
            {"tl", "Filipino/Tagalog"},
            {"sw", "Swahili"},
            {"am", "Amharic"},
            {"yo", "Yoruba"},
            {"ig", "Igbo"},
            {"ha", "Hausa"},
            {"zu", "Zulu"},
            {"af", "Afrikaans"},
            {"xh", "Xhosa"}
        };

        public Iteration1ApiController(
            ApplicationDbContext context, 
            IWebHostEnvironment env, 
            ILogger<Iteration1ApiController> logger,
            SignInManager<ApplicationUser> signInManager,
            UserManager<ApplicationUser> userManager,
            HttpClient httpClient,
            IOptions<AISettings> aISettings,
            IServiceScopeFactory scopeFactory)
        {
            _context = context;
            _env = env;
            _logger = logger;
            _signInManager = signInManager;
            _userManager = userManager;
            _httpClient = httpClient;
            _aISettings = aISettings.Value;
            _scopeFactory = scopeFactory;
        }

        // ===== USER API =====
        [HttpGet("user")]
        public async Task<IActionResult> GetCurrentUser()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            try
            {
                var user = await _context.Users.FindAsync(userId);
                if (user == null)
                    return NotFound("User not found");

                // Check if we're in impersonation mode
                var isImpersonating = User.FindFirst("IsImpersonating")?.Value == "true";
                var originalUserId = User.FindFirst("OriginalUserId")?.Value;

                var userInfo = new
                {
                    id = user.Id,
                    name = user.UserName,
                    email = user.Email,
                    role = User.FindFirst(ClaimTypes.Role)?.Value,
                    isImpersonating = isImpersonating,
                    originalUserId = originalUserId
                };

                return Ok(userInfo);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving current user information for userId: {UserId}", userId);
                return StatusCode(500, "Error retrieving user information");
            }
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            try
            {
                await _signInManager.SignOutAsync();
                return Ok(new { message = "Logged out successfully", redirectUrl= "/" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during logout");
                return StatusCode(500, new { message = "Failed to logout" });
            }
        }

        [HttpPost("enroll")]
        [AllowAnonymous]
        public async Task<IActionResult> EnrollUser([FromBody] UserEnrollmentRequest request)
        {
            try
            {
                // Validate required fields
                if (string.IsNullOrEmpty(request.FirstName) || string.IsNullOrEmpty(request.LastName) ||
                    string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
                {
                    return BadRequest(new { error = "First name, last name, email, and password are required" });
                }

                // Check if user already exists
                var existingUser = await _userManager.FindByEmailAsync(request.Email);
                if (existingUser != null)
                {
                    return BadRequest(new { error = "A user with this email address already exists" });
                }

                // Handle company creation if company account is selected
                UserGroup organization = null;
                if (request.IsCompanyAccount && !string.IsNullOrEmpty(request.CompanyName))
                {
                    organization = new UserGroup
                    {
                        Name = request.CompanyName,
                        NormalizedName = request.CompanyName,
                        Phone = request.ReuseContactInfo ? request.CellPhone : request.CompanyPhone,
                        PrimaryContactFirstName = request.ReuseContactInfo ? request.FirstName : request.PrimaryContactFirstName,
                        PrimaryContactLastName = request.ReuseContactInfo ? request.LastName : request.PrimaryContactLastName,
                        PrimaryContactEmail = request.ReuseContactInfo ? request.Email : request.PrimaryContactEmail,
                        Address1 = request.ReuseContactInfo ? request.Address1 : request.CompanyAddress1,
                        Address2 = request.ReuseContactInfo ? request.Address2 : request.CompanyAddress2,
                        City = request.ReuseContactInfo ? request.City : request.CompanyCity,
                        State = request.ReuseContactInfo ? request.State : request.CompanyState,
                        ZipCode = request.ReuseContactInfo ? request.ZipCode : request.CompanyZipCode,
                        Country = request.ReuseContactInfo ? request.Country : request.CompanyCountry,
                        CreatedAt = DateTime.UtcNow
                    };

                    _context.UserGroups.Add(organization);
                    await _context.SaveChangesAsync();
                }

                // Create the user
                var user = new ApplicationUser
                {
                    UserName = request.Email,
                    Email = request.Email,
                    EmailConfirmed = false, // Requires approval
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    CellPhone = request.CellPhone,
                    LandlinePhone = request.LandlinePhone,
                    Address1 = request.Address1,
                    Address2 = request.Address2,
                    City = request.City,
                    State = request.State,
                    ZipCode = request.ZipCode,
                    Country = request.Country,
                    CreatedAt = DateTime.UtcNow
                };

                var result = await _userManager.CreateAsync(user, request.Password);

                if (result.Succeeded)
                {
                    // Add user to organization (many-to-many)
                    if (organization != null)
                    {
                        user.Groups.Add(organization);
                        await _context.SaveChangesAsync(); // EF Core will insert into AspNetUserGroupMembers automatically
                    }

                    // Assign default role
                    await _userManager.AddToRoleAsync(user, "User");

                    return Ok(new
                    {
                        message = "Registration successful. Your account is pending approval.",
                        userId = user.Id,
                        requiresApproval = true
                    });
                }

                return BadRequest(new { error = "Failed to create user account", details = result.Errors });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Registration failed. Please try again." });
            }
        }

        // ===== PROJECTS API =====
        [HttpGet("projects")]
        public async Task<IActionResult> GetProjects()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userGroup = await GetUserGroup(userId);

            var projects = await _context.Projects
                        .Where(p => p.UserId == userId || (userGroup != null && p.GroupId == userGroup.Id))
                        .Select(p => new
                        {
                            id = p.Id.ToString(),
                            name = p.Name,
                            description = "Health and Safety Training Project",
                            documentsCount = _context.Assets.Count(a => a.ProjectId == p.Id && a.IsActive),
                            createdAt = p.DateCreated,
                            status = "active"
                        })
                        .OrderByDescending(p => p.createdAt)
                        .ToListAsync();

            return Ok(projects);
        }

        [HttpGet("projects/{id}")]
        public async Task<IActionResult> GetProject(int id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userGroup = await GetUserGroup(userId);

            var project = await _context.Projects
                        .Where(p => p.Id == id && (p.UserId == userId || (userGroup != null && p.GroupId == userGroup.Id)))
                        .Select(p => new
                        {
                            id = p.Id.ToString(),
                            name = p.Name,
                            description = "Health and Safety Training Project",
                            documentsCount = _context.Assets.Count(a => a.ProjectId == p.Id && a.IsActive),
                            createdAt = p.DateCreated,
                            status = "active"
                        })
                        .FirstOrDefaultAsync();

            if (project == null)
                return NotFound();

            return Ok(project);
        }

        [HttpPost("projects")]
        public async Task<IActionResult> CreateProject([FromBody] CreateProjectRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userGroup = await GetUserGroup(userId);

            var project = new Project
            {
                Name = request.Name,
                UserId = userId,
                DateCreated = DateTime.UtcNow,
                GroupId = userGroup?.Id
            };

            await _context.Projects.AddAsync(project);
            await _context.SaveChangesAsync();

            // Create default primer
            //var defaultPrimer = new ProjectPrimer
            //{
            //    ProjectId = project.Id,
            //    Name = "Safety Training Primer",
            //    Description = "Primary training content",
            //    ReadingLevel = 8,
            //    TargetLanguages = "[\"en-US\",\"es\",\"vi\"]",
            //    Status = "Draft",
            //    CreatedBy = userId!,
            //    ModifiedBy = userId!
            //};

            //await _context.ProjectPrimers.AddAsync(defaultPrimer);
            //await _context.SaveChangesAsync();

            return Ok(new { id = project.Id.ToString(), name = project.Name });
        }

        [HttpPatch("projects/{id}")]
        public async Task<IActionResult> UpdateProject(int id, [FromBody] UpdateProjectRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userGroup = await GetUserGroup(userId);

            var project = await _context.Projects
                        .Where(p => p.Id == id && (p.UserId == userId || (userGroup != null && p.GroupId == userGroup.Id)))
                        .FirstOrDefaultAsync();

            if (project == null)
                return NotFound();

            // Update project properties
            project.Name = request.Name ?? project.Name;
            // Note: Description is not stored in database, it's hardcoded
            // In a full implementation, you'd add a Description field to the Project model

            _context.Projects.Update(project);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                id = project.Id.ToString(),
                name = project.Name,
                success = true,
                message = "Project updated successfully"
            });
        }

        [HttpDelete("projects/{projectId}")]
        public async Task<IActionResult> DeleteProject(int projectId)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (!await HasProjectAccess(projectId, userId))
                    return Forbid();

                var userGroup = await GetUserGroup(userId);
                var groupName = userGroup?.Name ?? "Default";

                // Get project details for logging
                var project = await _context.Projects.FindAsync(projectId);
                if (project == null)
                    return NotFound(new { message = "Project not found" });

                var uploadPath = Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId.ToString());

                // Step 1: Delete physical folder
                if (Directory.Exists(uploadPath))
                {
                    Directory.Delete(uploadPath, recursive: true); // deletes folder + subfolders + files
                }

                _context.Projects.Remove(project);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    success = true,
                    message = $"Project '{project.Name}' deleted successfully"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting project {projectId}");
                return StatusCode(500, new { message = "Failed to delete project", error = ex.Message });
            }
        }

        // ===== DOCUMENTS API =====
        [HttpGet("documents/{projectId}")]
        public async Task<IActionResult> GetDocuments(int projectId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!await HasProjectAccess(projectId, userId))
                return Forbid();

            var documents = await _context.Assets
                        .Where(a => a.ProjectId == projectId && a.IsActive)
                        .Select(a => new
                        {
                            id = a.GuidId,
                            originalName = a.Name,
                            uploadDate = a.DateUploaded,
                            fileSize = a.FileSize,
                            status = GetProcessingStatus(a.Id),
                            fileType = a.AssetType
                        })
                        .OrderByDescending(a => a.uploadDate)
                        .ToListAsync();

            return Ok(documents);
        }

        [HttpPost("documents/upload")]
        //[RequestSizeLimit(52428800)] // 50MB limit
        //[RequestFormLimits(MultipartBodyLengthLimit = 52428800)]
        //[Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadDocument(IFormFile file, [FromForm] int projectId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!await HasProjectAccess(projectId, userId))
                return Forbid();

            if (file == null || file.Length == 0)
                return BadRequest("No file provided");

            var userGroup = await GetUserGroup(userId);
            var groupName = userGroup?.Name ?? "Default";

            // Create upload directory structure
            var uploadPath = Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId.ToString());
            Directory.CreateDirectory(uploadPath);

            var guidId = Guid.NewGuid().ToString();
            var fileName = $"{guidId}_{file.FileName}";
            var filePath = Path.Combine(uploadPath, fileName);

            // Save file
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            // Create database record
            var asset = new Asset
            {
                Name = file.FileName,
                FilePath = Path.Combine("Uploads", groupName, projectId.ToString(), fileName),
                UserId = userId!,
                DateUploaded = DateTime.UtcNow,
                IsActive = true,
                ProjectId = projectId,
                GuidId = guidId,
                AssetType = GetFileType(file.FileName),
                FlowNodeType = "document",
                FileSize = file.Length,
                LastModified = DateTime.UtcNow,
                ModifiedBy = userId!
            };

            await _context.Assets.AddAsync(asset);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                id = asset.GuidId,
                filename = asset.Name,
                uploadDate = asset.DateUploaded,
                size = asset.FileSize,
                status = "uploaded"
            });
        }

        [HttpGet("documents/{id}/download")]
        public async Task<IActionResult> DownloadDocument(string id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            try
            {
                // Find the document in the database
                var asset = await _context.Assets
                    .Where(d => d.GuidId.ToString() == id)
                    .FirstOrDefaultAsync();

                if (asset == null)
                    return NotFound(new { message = "Document not found" });

                // Check project access
                if (!await HasProjectAccess(asset.ProjectId, userId))
                    return Forbid();

                // Get organization context
                var userGroup = await GetUserGroup(userId);
                var groupName = userGroup?.Name ?? "Default";

                
                var foundPath = Path.Combine(_env.WebRootPath, asset.FilePath);
                if (!System.IO.File.Exists(foundPath))
                {
                    return NotFound(new { message = "Document file not found on disk" });
                }

                // Read file content
                var fileBytes = await System.IO.File.ReadAllBytesAsync(foundPath);

                // Set appropriate headers for download
                var sanitizedFileName = asset.Name.Replace("\"", "\\\"");

                return File(fileBytes, "application/octet-stream", sanitizedFileName);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to download document", error = ex.Message });
            }
        }

        // ===== PROJECT PRIMERS API =====
        [HttpGet("project-primers/{projectId}")]
        public async Task<IActionResult> GetProjectPrimers(int projectId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!await HasProjectAccess(projectId, userId))
                return Forbid();

            var primers = await _context.ProjectPrimers
                        .Where(p => p.ProjectId == projectId && p.IsActive)
                        .Select(p => new
                        {
                            id = p.Id,
                            name = p.Name,
                            description = p.Description,
                            readingLevel = p.ReadingLevel,
                            targetLanguages = p.TargetLanguages,
                            status = p.Status,
                            createdAt = p.CreatedAt,
                            lastModified = p.LastModified
                        })
                        .OrderBy(p => p.createdAt)
                        .ToListAsync();

            return Ok(primers);
        }

        [HttpPost("project-primers")]
        public async Task<IActionResult> CreateProjectPrimer([FromBody] CreatePrimerRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!await HasProjectAccess(request.ProjectId, userId))
                return Forbid();

            var primer = new ProjectPrimer
            {
                ProjectId = request.ProjectId,
                Name = request.Name,
                Description = request.Description,
                ReadingLevel = request.ReadingLevel,
                TargetLanguages = JsonSerializer.Serialize(request.TargetLanguages),
                Status = "Draft",
                CreatedBy = userId!,
                ModifiedBy = userId!
            };

            await _context.ProjectPrimers.AddAsync(primer);
            await _context.SaveChangesAsync();

            return Ok(new { id = primer.Id, name = primer.Name });
        }

        [HttpPut("project-primers/{id}")]
        public async Task<IActionResult> UpdateProjectPrimer(int id, [FromBody] UpdatePrimerRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var primer = await _context.ProjectPrimers.FindAsync(id);

            if (primer == null || !await HasProjectAccess(primer.ProjectId, userId))
                return NotFound();

            primer.Name = request.Name ?? primer.Name;
            primer.Description = request.Description ?? primer.Description;
            primer.ReadingLevel = request.ReadingLevel ?? primer.ReadingLevel;
            primer.TargetLanguages = request.TargetLanguages != null 
                ? JsonSerializer.Serialize(request.TargetLanguages) 
                : primer.TargetLanguages;
            primer.Status = request.Status ?? primer.Status;
            primer.LastModified = DateTime.UtcNow;
            primer.ModifiedBy = userId!;

            _context.ProjectPrimers.Update(primer);
            await _context.SaveChangesAsync();

            return Ok(new { id = primer.Id, name = primer.Name });
        }

        // ===== ASSETS API =====
        [HttpGet("assets/project/{projectId}")]
        public async Task<IActionResult> GetAssets(int projectId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!await HasProjectAccess(projectId, userId))
                return Forbid();

            var assets = await _context.Assets
                        .Where(a => a.ProjectId == projectId && a.IsActive && a.FlowNodeType == "primer")
                        .Select(a => new
                        {
                            id = a.GuidId,
                            name = a.Name,
                            title = a.Name,
                            filePath = a.FilePath,
                            projectId = a.ProjectId,
                            createdAt = a.DateUploaded,
                            lastModified = a.LastModified,
                            type = "primer",
                            status = "published",
                            language = "en-US",
                            readingLevel = 8
                        })
                        .OrderByDescending(a => a.lastModified)
                        .ToListAsync();

            return Ok(assets);
        }

        [HttpGet("assets/{id}")]
        public async Task<IActionResult> GetAsset(string id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var asset = await _context.Assets
                        .Include(a=>a.ProjectPrimer)
                        .Where(a => a.GuidId == id && a.IsActive)
                        .FirstOrDefaultAsync();

            if (asset == null)
                return NotFound();

            if (!await HasProjectAccess(asset.ProjectId, userId))
                return Forbid();

            // Get the associated ProjectPrimer data for primer assets
            //var allProjectPrimers = await _context.ProjectPrimers.Where(p => p.ProjectId == asset.ProjectId && p.IsActive).ToListAsync();

            string content = "";
            var fullPath = Path.Combine(_env.WebRootPath, asset.FilePath);
            if (System.IO.File.Exists(fullPath))
            {
                try
                {
                    content = await System.IO.File.ReadAllTextAsync(fullPath);
                }
                catch (Exception ex)
                {
                   
                }
            }

            string language = asset.ProjectPrimer?.TargetLanguages;
            int? readingLevel = asset.ProjectPrimer?.ReadingLevel;
            string primerName = asset.ProjectPrimer?.Name;
            //if (allProjectPrimers.Any())
            //{
            //    // Extract language from asset filename first
            //    string filenameLanguage = ExtractLanguageFromFilename(asset.Name);

            //    // Find the matching ProjectPrimer for this specific language
            //    var matchingPrimer = allProjectPrimers.FirstOrDefault(p =>
            //        string.Equals(p.TargetLanguages?.Trim(), filenameLanguage, StringComparison.OrdinalIgnoreCase));


            //    // Use the matching primer's language and reading level, or fallback to filename detection
            //    language = matchingPrimer?.TargetLanguages?.Trim() ?? filenameLanguage;
            //    readingLevel = matchingPrimer.ReadingLevel;

            //    primerName = matchingPrimer.Name;
                
            //}

            return Ok(new
            {
                id = asset.GuidId,
                name = primerName,
                title = primerName,
                content = content,
                filePath = asset.FilePath,
                projectId = asset.ProjectId,
                createdAt = asset.DateUploaded,
                lastModified = asset.LastModified,
                fileType = asset.AssetType ?? "primer",
                //status = "published",
                language = language,
                readingLevel = readingLevel,
                fileSize = asset.FileSize
            });
        }

        [HttpDelete("documents/{id}")]
        public async Task<IActionResult> DeleteAsset(string id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var asset = await _context.Assets
                        .Where(a => a.GuidId == id && a.IsActive)
                        .FirstOrDefaultAsync();

            if (asset == null)
                return NotFound();

            if (!await HasProjectAccess(asset.ProjectId, userId))
                return Forbid();

            // Soft delete
            asset.IsActive = false;
            asset.LastModified = DateTime.UtcNow;
            asset.ModifiedBy = userId!;

            // Also delete physical file if it exists
            var fullPath = Path.Combine(_env.WebRootPath, asset.FilePath);
            if (System.IO.File.Exists(fullPath))
            {
                try
                {
                    System.IO.File.Delete(fullPath);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning($"Failed to delete physical file {fullPath}: {ex.Message}");
                }
            }

            _context.Assets.Update(asset);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Asset deleted successfully" });
        }

        [HttpDelete("assets/{id}")]
        public async Task<IActionResult> DeleteAsset2(string id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var asset = await _context.Assets
                        .Include(a => a.ProjectPrimer)
                        .Where(a => a.GuidId == id && a.IsActive)
                        .FirstOrDefaultAsync();

            if (asset == null)
                return NotFound();

            if (!await HasProjectAccess(asset.ProjectId, userId))
                return Forbid();

            // Soft delete
            asset.IsActive = false;
            asset.LastModified = DateTime.UtcNow;
            asset.ModifiedBy = userId!;
            //_context.Assets.Update(asset);
            if (asset.ProjectPrimer != null)
            {
                asset.ProjectPrimer.IsActive = false;
                asset.ProjectPrimer.LastModified = DateTime.UtcNow;
                asset.ProjectPrimer.ModifiedBy = userId!;
            } 

            await _context.SaveChangesAsync();

            // Also delete physical file if it exists
            var fullPath = Path.Combine(_env.WebRootPath, asset.FilePath);
            if (System.IO.File.Exists(fullPath))
            {
                try
                {
                    System.IO.File.Delete(fullPath);
                }
                catch (Exception ex)
                {
                   
                }
            }

            

            return Ok(new { message = "Asset deleted successfully" });
        }

        // ===== PRIMER GENERATION API =====

        [HttpPost("generate-primer")]
        public async Task<IActionResult> GeneratePrimer([FromBody] GeneratePrimerRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            // Basic validation
            if (!await HasProjectAccess(request.ProjectId, userId))
                return Forbid();

            if (request == null || string.IsNullOrWhiteSpace(request.PrimerName) || request.Languages == null || !request.Languages.Any())
                return BadRequest(new { message = "Invalid request parameters" });

            try
            {
                // Create job ID and status entry
                var jobId = Guid.NewGuid().ToString();
                var jobStatus = new JobStatus
                {
                    Id = jobId,
                    UserId = userId,
                    Status = "started",
                    Progress = 0,
                    Message = "Primer generation started...",
                    CreatedAt = DateTime.UtcNow
                };

                _jobStatuses.TryAdd(jobId, jobStatus);

                // Start background processing - fire and forget
                _ = Task.Run(async () =>
                {
                    await ProcessPrimerGenerationAsync(request, jobId, userId);
                });

                // Return 202 Accepted with job ID immediately
                return Accepted(new
                {
                    jobId = jobId,
                    message = "Primer generation started",
                    status = "started",
                    statusEndpoint = $"/api/iteration1/job-status/{jobId}"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to start primer generation", error = ex.Message });
            }
        }

        [HttpGet("job-status/{jobId}")]
        public async Task<IActionResult> GetJobStatus(string jobId)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized();

                if (string.IsNullOrEmpty(jobId))
                    return BadRequest(new { message = "Job ID is required" });

                // Look up job status
                if (_jobStatuses.TryGetValue(jobId, out var jobStatus))
                {
                    // Verify the job belongs to the current user
                    if (jobStatus.UserId != userId)
                        return Forbid();

                    return Ok(new
                    {
                        jobId = jobStatus.Id,
                        status = jobStatus.Status,
                        progress = jobStatus.Progress,
                        message = jobStatus.Message,
                        error = jobStatus.Error,
                        result = jobStatus.Result,
                        createdAt = jobStatus.CreatedAt,
                        completedAt = jobStatus.CompletedAt
                    });
                }
                else
                {
                    return NotFound(new { message = "Job not found" });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving job status", error = ex.Message });
            }
        }

        // ===== BACKGROUND PROCESSING METHODS =====
        private async Task ProcessPrimerGenerationAsync(GeneratePrimerRequest request, string jobId, string userId)
        {
            using var scope = _scopeFactory.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

            try
            {
                // Update status to processing
                if (_jobStatuses.TryGetValue(jobId, out var job))
                {
                    job.Status = "processing";
                    job.Progress = 10;
                    job.Message = "Processing documents...";
                }

                // Step 1: Retrieve and process ALL uploaded documents
                var documents = await context.Assets
                    .Where(a => a.UserId == userId &&
                                a.ProjectId == request.ProjectId &&
                               a.IsActive &&
                               (a.AssetType == "Word" || a.AssetType == "PDF" || a.AssetType == "PowerPoint"))
                    .ToListAsync();

                string combinedDocumentContent = "";
                var processedDocuments = 0;

                if (documents.Any())
                {
                    var documentContents = new List<string>();

                    foreach (var document in documents)
                    {
                        try
                        {
                            var documentPath = Path.Combine(_env.WebRootPath, document.FilePath);
                            string textContent = "";

                            // Extract text based on file type
                            if (document.Name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase))
                            {
                                textContent = await ExtractTextFromPdf(documentPath);
                            }
                            else if (document.Name.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                            {
                                textContent = await System.IO.File.ReadAllTextAsync(documentPath);
                            }
                            else if (document.Name.EndsWith(".pptx", StringComparison.OrdinalIgnoreCase))
                            {
                                textContent = await ExtractTextFromPptx(documentPath);
                            }
                            else if (document.Name.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                            {
                                textContent = await ExtractTextFromDocx(documentPath);
                            }
                            else
                            {
                                textContent = $"[Document: {document.Name}]";
                            }

                            if (!string.IsNullOrWhiteSpace(textContent))
                            {
                                documentContents.Add($"Source document: {document.Name}");
                                documentContents.Add(textContent);
                                documentContents.Add(""); // Separator
                                processedDocuments++;
                            }
                        }
                        catch (Exception docEx)
                        {
                        }
                    }

                    combinedDocumentContent = string.Join("\n", documentContents);
                }
                else
                {
                    var project = await context.Projects.FindAsync(request.ProjectId);
                    combinedDocumentContent = $"Project: {project?.Name ?? "Health and Safety Training"}\nContext: General workplace safety training requirements and best practices";
                }

                // Update progress
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Progress = 30;
                    job.Message = "Retrieving AI settings...";
                }

                // Step 2: Get custom algorithm settings (ChatGPT prompt)
                var algorithmSettings = await context.GlobalSettings
                    .FirstOrDefaultAsync(gs => gs.UserId == Guid.Empty.ToString() && gs.Key == "PrimerPrompt");

                var customPrompt = algorithmSettings?.Value;

                // Update progress
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Progress = 50;
                    job.Message = "Generating English primer with AI...";
                }

                // Step 3: Generate primers for each target language at specified reading level
                var generatedPrimers = new List<object>();
                var generatedAssets = new List<object>();
                var successCount = 0;

                //var userGroup = await GetUserGroup(userId);
                var userGroup = await context.UserGroups
                                .Where(ug => ug.Users.Any(u => u.Id == userId))
                                .FirstOrDefaultAsync();
                var groupName = userGroup?.Name ?? "Default";

                // Step 3a: Generate English primer first
                GeneratedPrimerContent englishPrimer = null;
                //string englishPrimer = null;
                var englishLang = "en-US";

                try
                {
                    englishPrimer = await GenerateHealthSafetyPrimer(
                        request.ProjectId,
                        request.ReadingLevel,
                        englishLang,
                        request.PrimerName,
                        combinedDocumentContent,
                        customPrompt
                    );

                    // Save English primer
                    var englishAsset = await CreatePrimerAsset(context, englishPrimer, request, englishLang, groupName, userId);
                    generatedAssets.Add(englishAsset);

                    generatedPrimers.Add(new
                    {
                        id = englishAsset.GetType().GetProperty("id")?.GetValue(englishAsset),
                        title = $"{request.PrimerName} (English)",
                        language = englishLang,
                        readingLevel = request.ReadingLevel,
                        objectives = englishPrimer.LearningObjectives,
                        glossary = englishPrimer.Glossary,
                        //objectives = new string[] { }, // Raw HTML - no structured objectives
                        //glossary = new object[] { }, // Raw HTML - no structured glossary
                        metadata = new
                        {
                            languageCode = englishLang,
                            readingLevel = request.ReadingLevel,
                            processedDocuments = processedDocuments,
                            contentLength = combinedDocumentContent.Length,
                            isEnglishMaster = true
                        }
                    });

                    successCount++;
                }
                catch (Exception engEx)
                {
                    generatedPrimers.Add(new
                    {
                        error = $"Failed to generate English primer: {engEx.Message}",
                        language = englishLang,
                        title = $"{request.PrimerName} (English) - Generation Failed"
                    });
                }

                // Update progress
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Progress = 80;
                    job.Message = "Translating to additional languages...";
                }

                // Step 3b: Generate translations for other languages using ChatGPT
                var otherLanguages = request.Languages.Where(lang => lang != englishLang).ToArray();

                if (otherLanguages.Any() && englishPrimer != null)
                {
                    foreach (var language in otherLanguages)
                    {
                        try
                        {
                            var translatedPrimer = await TranslatePrimerToLanguage(englishPrimer, language, request.ReadingLevel);

                            // Save translated primer
                            var translatedAsset = await CreatePrimerAsset(context, translatedPrimer, request, language, groupName, userId);
                            generatedAssets.Add(translatedAsset);

                            generatedPrimers.Add(new
                            {
                                id = translatedAsset.GetType().GetProperty("id")?.GetValue(translatedAsset),
                                title = $"{request.PrimerName} ({GetLanguageName(language)})",
                                language = language,
                                readingLevel = request.ReadingLevel,
                                //objectives = translatedPrimer.LearningObjectives,
                                //glossary = translatedPrimer.Glossary,
                                objectives = new string[] { }, // Raw HTML - no structured objectives
                                glossary = new object[] { }, // Raw HTML - no structured glossary
                                metadata = new
                                {
                                    languageCode = language,
                                    readingLevel = request.ReadingLevel,
                                    translatedFrom = englishLang,
                                    isTranslation = true
                                }
                            });

                            successCount++;
                        }
                        catch (Exception langEx)
                        {
                            generatedPrimers.Add(new
                            {
                                error = $"Failed to translate to {GetLanguageName(language)}: {langEx.Message}",
                                language = language,
                                title = $"{request.PrimerName} ({GetLanguageName(language)}) - Translation Failed"
                            });
                        }
                    }
                }

                await context.SaveChangesAsync();

                // Update job to completed
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    if (successCount == 0)
                    {
                        job.Status = "failed";
                        job.Error = $"Failed to generate primers for all {request.Languages.Length} languages";
                    }
                    else
                    {
                        job.Status = "completed";
                        job.Progress = 100;
                        job.Message = "Primer generation completed successfully";
                        job.Result = new
                        {
                            success = true,
                            message = $"Generated primers for {successCount}/{request.Languages.Length} language(s) using English-first approach",
                            primers = generatedPrimers,
                            assets = generatedAssets,
                            languageCount = successCount,
                            requestedLanguages = request.Languages.Length,
                            documentsSummary = new
                            {
                                processedDocuments = processedDocuments,
                                totalContentLength = combinedDocumentContent.Length,
                                documentNames = documents.Select(d => d.Name).ToList()
                            }
                        };
                    }
                    job.CompletedAt = DateTime.UtcNow;
                }
            }
            catch (Exception ex)
            {
                // Update job to failed
                if (_jobStatuses.TryGetValue(jobId, out var job))
                {
                    job.Status = "failed";
                    job.Error = ex.Message;
                    job.CompletedAt = DateTime.UtcNow;
                }
            }
        }

        [HttpPut("assets/{id}/content")]
        public async Task<IActionResult> UpdateAssetContent(string id, [FromBody] UpdateAssetContentRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var asset = await _context.Assets
                        .Where(a => a.GuidId == id && a.IsActive)
                        .FirstOrDefaultAsync();

            if (asset == null)
                return NotFound();

            if (!await HasProjectAccess(asset.ProjectId, userId))
                return Forbid();

            try
            {
                // Update asset properties
                asset.Name = asset.Name;
                asset.LastModified = DateTime.UtcNow;
                asset.ModifiedBy = userId!;

                // Save the content to the physical file
                var fullPath = Path.Combine(_env.WebRootPath, asset.FilePath);

                // Ensure directory exists
                var directory = Path.GetDirectoryName(fullPath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Write content to file
                await System.IO.File.WriteAllTextAsync(fullPath, request.Content ?? "");

                // Update file size
                asset.FileSize = new FileInfo(fullPath).Length;

                await _context.SaveChangesAsync();

                return Ok(new
                {
                    success = true,
                    message = "Content saved successfully",
                    asset = new
                    {
                        id = asset.GuidId,
                        name = asset.Name,
                        title = request.Title ?? asset.Name,
                        lastModified = asset.LastModified
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving content for asset {AssetId}", id);
                return StatusCode(500, new { message = "Failed to save content", error = ex.Message });
            }
        }

        [HttpGet("projects/{projectId}/assets")]
        public async Task<IActionResult> GetProjectAssetsWithLanguageDetection(int projectId)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (!await HasProjectAccess(projectId, userId))
                    return Forbid();

                // Get assets from database
                var assets = await _context.Assets
                    .Where(a => a.ProjectId == projectId && a.AssetType == "Primer" && a.IsActive)
                    .OrderByDescending(a => a.DateUploaded)
                    .ToListAsync();

                // Get project primer information for reading level and target languages
                var allProjectPrimers = await _context.ProjectPrimers
                    .Where(p => p.ProjectId == projectId && p.IsActive)
                    .ToListAsync();

                var response = new List<object>();
                foreach (var asset in assets)
                {
                    // Extract language from asset filename first
                    //string filenameLanguage = ExtractLanguageFromFilename(asset.Name);

                    // Find the matching ProjectPrimer for this specific language
                    //var matchingPrimer = allProjectPrimers.FirstOrDefault(p => string.Equals(p.TargetLanguages?.Trim(), filenameLanguage, StringComparison.OrdinalIgnoreCase));


                    // Use the matching primer's language and reading level, or fallback to filename detection
                    //string detectedLanguage = matchingPrimer?.TargetLanguages?.Trim() ?? filenameLanguage;
                    string detectedLanguage = asset.ProjectPrimer?.TargetLanguages;
                    //string readingLevel = matchingPrimer?.ReadingLevel.ToString() ?? "8";
                    string readingLevel = asset.ProjectPrimer?.ReadingLevel.ToString();

                    response.Add(new
                    {
                        id = asset.GuidId?.ToString() ?? asset.Id.ToString(),
                        filename = asset.Name,
                        originalName = asset.Name,
                        title = asset.Name?.Replace(".html", "").Replace("-", " "),
                        type = asset.AssetType,
                        size = asset.FileSize,
                        createdAt = asset.DateUploaded,
                        lastModified = asset.LastModified,
                        projectId = projectId,
                        metadata = new
                        {
                            languageCode = detectedLanguage,
                            language = detectedLanguage,
                            readingLevel = readingLevel,
                            assetType = asset.AssetType,
                            filePath = asset.FilePath
                        }
                    });
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to fetch assets", error = ex.Message });
            }
        }

        // ===== QUIZ QUESTIONS API =====

        [HttpPost("generate-quiz-json/{projectId}")]
        public async Task<IActionResult> GenerateQuizJSON(int projectId, [FromBody] GenerateQuizRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            try
            {
                // Basic validation only
                if (projectId == 0 || request == null)
                {
                    return BadRequest(new { message = "Missing required fields: projectId or request body" });
                }

                // Check project access
                if (!await HasProjectAccess(projectId, userId))
                {
                    return Forbid();
                }

                // Quick check for documents (without expensive operations)
                var hasDocuments = await _context.Assets
                    .AnyAsync(a => a.UserId == userId &&
                                   a.ProjectId == projectId &&
                                   a.IsActive &&
                                   (a.AssetType == "Word" || a.AssetType == "PDF" || a.AssetType == "PowerPoint"));

                if (!hasDocuments)
                {
                    return BadRequest(new { message = "No documents found for this project" });
                }

                // Generate unique job ID
                var jobId = Guid.NewGuid().ToString();

                // Initialize job status as "started" immediately
                _jobStatuses[jobId] = new JobStatus
                {
                    Id = jobId,
                    UserId = userId,
                    Status = "started",
                    Progress = 0,
                    Message = "Quiz generation job queued for processing",
                    CreatedAt = DateTime.UtcNow
                };

                // Start background processing with Task.Run
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await ProcessQuizGenerationAsync(projectId, request, jobId, userId);
                    }
                    catch (Exception ex)
                    {
                        // Update job status to failed
                        if (_jobStatuses.TryGetValue(jobId, out var failedJob))
                        {
                            failedJob.Status = "failed";
                            failedJob.Error = ex.Message;
                            failedJob.CompletedAt = DateTime.UtcNow;
                        }
                    }
                });

                // Return 202 Accepted immediately with job tracking info
                return Accepted(new
                {
                    jobId = jobId,
                    statusUrl = $"/api/iteration1/job-status/{jobId}",
                    message = "Quiz generation started in background. Use statusUrl to check progress."
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to start quiz generation", error = ex.Message });
            }
        }

        private async Task ProcessQuizGenerationAsync(int projectId, GenerateQuizRequest request, string jobId, string userId)
        {
            using var scope = _scopeFactory.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

            try
            {
                // Update status to processing
                if (_jobStatuses.TryGetValue(jobId, out var job))
                {
                    job.Status = "processing";
                    job.Progress = 10;
                    job.Message = "Processing documents...";
                }

                //var userGroup = await GetUserGroup(userId);
                var userGroup = await context.UserGroups
                                .Where(ug => ug.Users.Any(u => u.Id == userId))
                                .FirstOrDefaultAsync();
                var groupName = userGroup?.Name ?? "Default";

                // Get documents for the project
                var documents = await context.Assets
                                .Where(a => a.UserId == userId &&
                                            a.ProjectId == projectId &&
                                           a.IsActive &&
                                           (a.AssetType == "Word" || a.AssetType == "PDF" || a.AssetType == "PowerPoint"))
                                .ToListAsync();

                if (!documents.Any())
                {
                    throw new InvalidOperationException("No documents found for this project");
                }

                // Update progress
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Progress = 30;
                    job.Message = "Extracting document content...";
                }

                // Extract document content
                var documentContents = new List<DocumentContent>();
                foreach (var doc in documents)
                {
                    try
                    {
                        var content = await ExtractDocumentContent(doc);
                        documentContents.Add(new DocumentContent
                        {
                            Name = doc.Name,
                            Content = content
                        });
                    }
                    catch (Exception ex)
                    {
                        
                    }
                }

                // Update progress
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Progress = 50;
                    job.Message = "Generating quiz with AI...";
                }

                var projectPrimer = await context.ProjectPrimers.Where(p => p.ProjectId == projectId && p.IsActive).FirstOrDefaultAsync();

                // Generate quiz using AI service
                var quizData = await GenerateQuizWithAI(userId,context, new QuizGenerationParams
                {
                    ProjectId = projectId.ToString(),
                    PrimerName = projectPrimer?.Name,
                    ReadingLevel = projectPrimer?.ReadingLevel.ToString(),
                    Language = request.Language,
                    DocumentContents = documentContents
                });

                // Update progress
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Progress = 80;
                    job.Message = "Formatting and saving quiz...";
                }

                // Convert to proper format for frontend
                if (quizData.Questions != null)
                {
                    for (int i = 0; i < quizData.Questions.Count; i++)
                    {
                        var question = quizData.Questions[i];

                        // Ensure proper format with optionA/B/C/D
                        if (question.Options != null && question.Options.Count >= 4)
                        {
                            question.OptionA = question.Options[0];
                            question.OptionB = question.Options[1];
                            question.OptionC = question.Options[2];
                            question.OptionD = question.Options[3];
                        }

                        // Ensure correctAnswer is a letter
                        if (int.TryParse(question.CorrectAnswer, out int index))
                        {
                            question.CorrectAnswer = new[] { "A", "B", "C", "D" }[Math.Min(index, 3)];
                        }
                    }
                }

                // Save quiz file
                var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH-mm-ss");
                var filename = $"{timestamp}_{request.PrimerName.ToLower().Replace(" ", "-")}-quiz.json";

                var uploadPath = Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId.ToString());
                var filePath = Path.Combine(uploadPath, filename);

                // Convert object → JSON
                var json = JsonSerializer.Serialize(quizData, new JsonSerializerOptions
                {
                    WriteIndented = true
                });
                await System.IO.File.WriteAllTextAsync(filePath, json);

                // Update job to completed
                if (_jobStatuses.TryGetValue(jobId, out job))
                {
                    job.Status = "completed";
                    job.Progress = 100;
                    job.Message = "Quiz generation completed successfully";
                    job.Result = new
                    {
                        quiz = quizData,
                        filename = filename,
                        filePath = Path.Combine("Uploads", groupName, projectId.ToString(), filename)
                    };
                    job.CompletedAt = DateTime.UtcNow;
                }
            }
            catch (Exception ex)
            {
                // Update job to failed
                if (_jobStatuses.TryGetValue(jobId, out var job))
                {
                    job.Status = "failed";
                    job.Error = ex.Message;
                    job.CompletedAt = DateTime.UtcNow;
                }
            }
        }

        [HttpGet("quiz-json-files/{projectId}")]
        public async Task<IActionResult> GetQuizJsonFiles(string projectId)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userGroup = await GetUserGroup(userId);
                var groupName = userGroup?.Name ?? "Default";

                if (string.IsNullOrEmpty(projectId))
                {
                    return BadRequest(new { message = "Project ID is required" });
                }

                var uploadPath = Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId);

                if (!Directory.Exists(uploadPath))
                {
                    return Ok(new { quizFiles = new List<object>() });
                }

                var projectPrimer = await _context.ProjectPrimers.Where(p => p.ProjectId.ToString() == projectId && p.IsActive).FirstOrDefaultAsync();

                var quizFiles = new List<object>();
                var files = Directory.GetFiles(uploadPath, "*-quiz.json");

                foreach (var filePath in files)
                {
                    var fileInfo = new FileInfo(filePath);
                    var filename = fileInfo.Name;

                    try
                    {
                        var jsonContent = System.IO.File.ReadAllText(filePath);
                        var quizData = JsonSerializer.Deserialize<dynamic>(jsonContent);

                        quizFiles.Add(new
                        {
                            filename,
                            path = filePath,
                            size = fileInfo.Length,
                            createdAt = fileInfo.CreationTime,
                            modifiedAt = fileInfo.LastWriteTime,
                            title = $"{projectPrimer?.Name} - English",
                            projectPrimer?.Name,
                            language = "en-US",
                            languageName = "English",
                            languageFlag = "🇺🇸",
                            readingLevel = projectPrimer?.ReadingLevel,
                            questionCount = 10,
                            difficulty = "Mixed",
                            metadata = new
                            {
                                totalQuestions = 10,
                                hasInstructions = false,
                                hasTimer = false,
                                categories = new List<string>()
                            }
                        });
                    }
                    catch
                    {
                        
                    }
                }

                return Ok(quizFiles);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to fetch quiz files", error = ex.Message });
            }
        }

        [HttpGet("quiz-json/{projectId}/{filename}")]
        public async Task<IActionResult> GetQuizJsonFile(string projectId, string filename)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userGroup = await GetUserGroup(userId);
                var groupName = userGroup?.Name ?? "Default";

                if (string.IsNullOrEmpty(projectId) || string.IsNullOrEmpty(filename))
                {
                    return BadRequest(new { message = "Project ID and filename are required" });
                }

                // Try multiple possible directory paths to find quiz file
                var possiblePaths = new[]
                {
                    Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId, filename),
                    Path.Combine(_env.WebRootPath, "Uploads", "Default", projectId, filename)
                };

                string filePath = null;
                foreach (var testPath in possiblePaths)
                {
                    if (System.IO.File.Exists(testPath))
                    {
                        filePath = testPath;
                        break;
                    }
                }

                if (string.IsNullOrEmpty(filePath))
                {
                    return NotFound(new { message = "Quiz file not found" });
                }

                var jsonContent = await System.IO.File.ReadAllTextAsync(filePath);
                var quizData = JsonSerializer.Deserialize<object>(jsonContent);

                return Ok(new
                {
                    quiz = quizData,
                    filename = filename,
                    filePath = filePath
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to load quiz file", error = ex.Message });
            }
        }

        [HttpPut("quiz-json/{projectId}/{filename}")]
        public async Task<IActionResult> UpdateQuizJsonFile(string projectId, string filename, [FromBody] UpdateQuizRequest request)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userGroup = await GetUserGroup(userId);
                var groupName = userGroup?.Name ?? "Default";

                if (string.IsNullOrEmpty(projectId) || string.IsNullOrEmpty(filename))
                {
                    return BadRequest(new { message = "Project ID and filename are required" });
                }

                if (!filename.EndsWith("-quiz.json"))
                {
                    return BadRequest(new { message = "Invalid quiz file" });
                }

                // Try multiple possible directory paths to find quiz file
                var possiblePaths = new[]
                {
                    Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId, filename),
                    Path.Combine(_env.WebRootPath, "Uploads", "Default", projectId, filename)
                };

                string filePath = null;
                foreach (var testPath in possiblePaths)
                {
                    if (System.IO.File.Exists(testPath))
                    {
                        filePath = testPath;
                        break;
                    }
                }

                if (string.IsNullOrEmpty(filePath))
                {
                    return NotFound(new { message = "Quiz file not found" });
                }

                // Validate quiz data structure
                if (request.QuizData == null)
                {
                    return BadRequest(new { message = "Invalid quiz data format" });
                }

                // Save updated quiz data
                var jsonContent = JsonSerializer.Serialize(request.QuizData, new JsonSerializerOptions { WriteIndented = true });
                await System.IO.File.WriteAllTextAsync(filePath, jsonContent);

                return Ok(new
                {
                    success = true,
                    message = "Quiz updated successfully",
                    filename = filename,
                    quiz = request.QuizData
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to update quiz file", error = ex.Message });
            }
        }

        [HttpDelete("quiz-json/{projectId}/{filename}")]
        public async Task<IActionResult> DeleteQuizJsonFile(string projectId, string filename)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userGroup = await GetUserGroup(userId);
                var groupName = userGroup?.Name ?? "Default";

                if (string.IsNullOrEmpty(projectId) || string.IsNullOrEmpty(filename))
                {
                    return BadRequest(new { message = "Project ID and filename are required" });
                }

                if (!filename.EndsWith("-quiz.json"))
                {
                    return BadRequest(new { message = "Invalid quiz file" });
                }

                // Try multiple possible directory paths to find quiz file
                var possiblePaths = new[]
                {
                    Path.Combine(_env.WebRootPath, "Uploads", groupName, projectId, filename),
                    Path.Combine(_env.WebRootPath, "Uploads", "Default", projectId, filename)
                };

                string filePath = null;
                foreach (var testPath in possiblePaths)
                {
                    if (System.IO.File.Exists(testPath))
                    {
                        filePath = testPath;
                        break;
                    }
                }

                if (string.IsNullOrEmpty(filePath))
                {
                    return NotFound(new { message = "Quiz file not found" });
                }

                System.IO.File.Delete(filePath);

                return Ok(new
                {
                    success = true,
                    message = "Quiz file deleted successfully",
                    filename = filename
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to delete quiz file", error = ex.Message });
            }
        }

        // ===== STUDENT PORTALS API =====
        [HttpGet("student-portals/{projectId}")]
        public async Task<IActionResult> GetStudentPortals(int projectId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!await HasProjectAccess(projectId, userId))
                return Forbid();

            var portals = await _context.StudentPortals
                        .Where(p => p.ProjectId == projectId && p.IsActive)
                        .Select(p => new
                        {
                            id = p.Id,
                            title = p.Title,
                            description = p.Description,
                            accessUrl = p.AccessUrl,
                            minPassingScore = p.MinPassingScore,
                            isPublished = p.IsPublished,
                            createdAt = p.CreatedAt
                        })
                        .OrderByDescending(p => p.createdAt)
                        .ToListAsync();

            return Ok(portals);
        }

        // ===== ADMIN USER MANAGEMENT API =====
        [HttpGet("admin/users")]
        [Authorize(Roles = "Superadmin")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var users = await _userManager.Users.ToListAsync();
                var userList = new List<object>();

                foreach (var user in users)
                {
                    var roles = await _userManager.GetRolesAsync(user);
                    var primaryRole = roles.FirstOrDefault() ?? "User";
                    var userGroup = await GetUserGroup(user.Id);

                    userList.Add(new
                    {
                        id = user.Id,
                        name = $"{user.FirstName} {user.LastName}".Trim(),
                        email = user.Email,
                        role = primaryRole,
                        organization = userGroup?.Name,
                        status = user.LockoutEnd.HasValue && user.LockoutEnd > DateTimeOffset.UtcNow
                                ? "suspended"
                                : user.EmailConfirmed
                                    ? "approved"
                                    : "pending"
                        //createdAt = user.CreatedAt ?? DateTime.UtcNow,
                        //lastLoginAt = user.LastLoginDate
                    });
                }

                return Ok(userList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to retrieve users" });
            }
        }

        [HttpGet("admin/organizations")]
        [Authorize(Roles = "Superadmin")]
        public async Task<IActionResult> GetAllOrganizations()
        {
            try
            {
                var organizations = await _context.UserGroups.ToListAsync();
                var orgList = organizations.Select(org => new
                {
                    id = org.Id.ToString(),
                    name = org.Name
                }).ToList();

                return Ok(orgList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to retrieve organizations" });
            }
        }

        [HttpPost("admin/users/{userId}/approve")]
        [Authorize(Roles = "Superadmin")]
        public async Task<IActionResult> ApproveUser(string userId)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(userId);
                if (user == null)
                    return NotFound(new { error = "User not found" });

                user.EmailConfirmed = true;
                user.LockoutEnd = null;
                var result = await _userManager.UpdateAsync(user);

                // Check if already exists in AspNetUserGroupMembers
                bool alreadyExists = _context.Set<Dictionary<string, object>>("AspNetUserGroupMembers")
                                    .Any(j => (string)j["UserId"] == userId);

                if (!alreadyExists)
                {
                    _context.Set<Dictionary<string, object>>("AspNetUserGroupMembers")
                        .Add(new Dictionary<string, object>
                        {
                            ["UserId"] = userId,
                            ["GroupId"] = 1
                        });

                    _context.SaveChanges();
                }

                if (result.Succeeded)
                {
                    return Ok(new { message = "User approved successfully" });
                }

                return BadRequest(new { error = "Failed to approve user", details = result.Errors });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to approve user" });
            }
        }

        [HttpPost("admin/users/{userId}/reject")]
        [Authorize(Roles = "Superadmin")]
        public async Task<IActionResult> RejectUser(string userId)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(userId);
                if (user == null)
                    return NotFound(new { error = "User not found" });

                user.EmailConfirmed = false;
                user.LockoutEnabled = true;
                user.LockoutEnd = DateTimeOffset.MaxValue;

                var result = await _userManager.UpdateAsync(user);

                if (result.Succeeded)
                {
                    return Ok(new { message = "User rejected successfully" });
                }

                return BadRequest(new { error = "Failed to reject user", details = result.Errors });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to reject user" });
            }
        }

        [HttpPost("admin/users/{userId}/impersonate")]
        [Authorize(Roles = "Superadmin")]
        public async Task<IActionResult> ImpersonateUser(string userId)
        {
            try
            {
                var targetUser = await _userManager.FindByIdAsync(userId);
                if (targetUser == null)
                    return NotFound(new { error = "User not found" });

                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                var additionalClaims = new List<Claim>
                {
                    new Claim("OriginalUserId", currentUserId),
                    new Claim("IsImpersonating", "true")
                };

                //await _signInManager.SignInAsync(targetUser, isPersistent: false, additionalClaims: additionalClaims);

                var userPrincipal = await _signInManager.CreateUserPrincipalAsync(targetUser);

                // Add additional claims
                var identity = (ClaimsIdentity)userPrincipal.Identity;
                identity.AddClaims(additionalClaims);

                // Sign in with HttpContext
                await HttpContext.SignInAsync(IdentityConstants.ApplicationScheme, userPrincipal);

                return Ok(new { message = $"Impersonation started for user {targetUser.UserName}", userId = userId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to impersonate user" });
            }
        }

        [HttpPost("admin/return-to-admin")]
        [Authorize]
        public async Task<IActionResult> ReturnToAdmin()
        {
            try
            {
                // Check if we're currently impersonating
                var isImpersonating = User.FindFirst("IsImpersonating")?.Value == "true";
                var originalUserId = User.FindFirst("OriginalUserId")?.Value;

                if (!isImpersonating || string.IsNullOrEmpty(originalUserId))
                {
                    return BadRequest(new { error = "Not currently impersonating a user" });
                }

                // Get the original admin user
                var originalUser = await _userManager.FindByIdAsync(originalUserId);
                if (originalUser == null)
                {
                    return NotFound(new { error = "Original admin user not found" });
                }

                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                // Sign in as the original admin user without impersonation claims
                await _signInManager.SignInAsync(originalUser, isPersistent: false);

                return Ok(new
                {
                    message = "Successfully returned to admin account",
                    adminUserId = originalUserId
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to return to admin account" });
            }
        }

        [HttpPost("admin/users/{userId}/organization")]
        [Authorize(Roles = "Superadmin")]
        public async Task<IActionResult> AssignUserToOrganization(string userId, [FromBody] AssignOrganizationRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.OrganizationId))
                    return BadRequest(new { error = "Organization ID is required" });

                var user = await _userManager.Users
                            .Include(u => u.Groups) // important: load existing groups
                            .FirstOrDefaultAsync(u => u.Id == userId);
                if (user == null)
                    return NotFound(new { error = "User not found" });

                var organization = await _context.UserGroups.FindAsync(request.OrganizationId);
                if (organization == null)
                    return NotFound(new { error = "Organization not found" });


                user.Groups.Clear();
                user.Groups.Add(organization);

                await _context.SaveChangesAsync();

                return Ok(new { message = "User assigned to organization successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to assign user to organization" });
            }
        }

        // ===== ALGORITHM SETTINGS API =====
        [HttpGet("algorithm-settings")]
        public async Task<IActionResult> GetAlgorithmSettings()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();
            if (!User.IsInRole("Superadmin"))
                return Unauthorized();
            try
            {
                // Get user's organization
                var userGroup = await GetUserGroup(userId);
                var organizationId = userGroup?.Name ?? "default";
                // Look for existing algorithm settings in GlobalSettings table
                var primerPromptSetting = await _context.GlobalSettings
                    .Where(gs => gs.UserId == Guid.Empty.ToString() &&
                                gs.Category == "Algorithm" &&
                                gs.Key == "PrimerPrompt")
                    .FirstOrDefaultAsync();
                var quizPromptSetting = await _context.GlobalSettings
                    .Where(gs => gs.UserId == Guid.Empty.ToString() &&
                                gs.Category == "Algorithm" &&
                                gs.Key == "QuizPrompt")
                    .FirstOrDefaultAsync();
                // Default prompts if none exist
                var defaultPrimerPrompt = @"You are an expert health and safety trainer creating a comprehensive primer to best equip learners who will attend or take training where they may be at a disadvantage because of reading levels or language barriers. You want to create a primer that is tailored to the trainee as a supplement to the training they are about to receive. It is important the trainee know the learning objectives being covered and relate them to a short or long term health or safety risk. If the training covers worker rights, you can be sure to include such content in the objectives (i.e know your rights). Conversely if training does not cover it then do not inject it.
                    Key areas to pick up from the training materials:
                    - PPE requirements and proper usage specific to the hazards covered
                    - Health risks specific to the job/environment described in the documents
                    - Cautions and safety awareness relevant to the content
                    - Methods of injury prevention based on the documented procedures
                    - Methods you can get sick or injured - breathing, infection, fall, etc.
                    CRITICAL REQUIREMENT: You MUST create exactly 15-25 detailed learning objectives. Do not provide fewer than 15 objectives.
                    Generate content of these detailed learning objectives at the specified reading level. Each objective must contain specific, actionable information.
                    After the comprehensive bulleted list of learning objectives is created - any acronyms or terminology an 8th grader may not be familiar with needs to be placed into a detailed glossary.
                    Format as rich HTML suitable for Quill.js editor with headers, bold/italic emphasis, comprehensive bullet points and numbered lists, icons, color highlights for important safety points, and call-out boxes for critical information.

                Generate content at <%readinglevel%>th grade reading level. Create a comprehensive glossary for technical terms.

                Return JSON with this structure:
                {
                    ""title"": ""<%primerName%>"",
                    ""learningObjectives"": [
                        ""Understand basic safety protocols and procedures"",
                        ""Identify proper use of personal protective equipment"",
                        ""Recognize potential workplace hazards and risks""
                    ],
                    ""glossary"": [
                        {""term"": ""PPE"", ""definition"": ""Personal Protective Equipment used to minimize exposure to hazards""},
                        {""term"": ""Risk Assessment"", ""definition"": ""The process of identifying and evaluating potential hazards""}
                    ],
                    ""content"": ""Rich HTML content with formatting"",
                    ""readingLevel"": <%readinglevel%>,
                    ""language"": ""English (US)""
                }
                
                Create a comprehensive health and safety learning objectives document titled ""<%primerName%>"" based on these training materials:
                
                <%documentContent%>

                Requirements:
                1. Write at <%readinglevel%>th grade reading level
                2. Base content SPECIFICALLY on the provided documents
                3. Include 15-25 detailed learning objectives
                4. Create comprehensive glossary for technical terms
                5. Generate rich HTML content with visual formatting
                ";
                var defaultQuizPrompt = @"You are an expert health and safety training quiz generator. Based on the following training documents, generate 10-15 high-quality multiple choice questions suitable for the specified reading level.
                    Generate quiz questions that focus on:
                    1. Personal safety and protective equipment (PPE)
                    2. Health risks and symptoms to watch for
                    3. Proper procedures and protocols
                    4. Worker rights and reporting procedures
                    5. Injury prevention and emergency response
                    Use EXACTLY this JSON format - the frontend expects optionA, optionB, optionC, optionD and correctAnswer as a letter:
                    {
                      ""title"": ""<%primerName%>"",
                      ""readingLevel"": ""<%readinglevel%>"",
                      ""language"": ""English (US)"",
                      ""questions"": [
                        {
                          ""question"": ""What should you wear when working with hazardous materials?"",
                          ""optionA"": ""Regular work clothes"",
                          ""optionB"": ""Appropriate PPE as specified in safety protocols"",
                          ""optionC"": ""Just safety glasses"",
                          ""optionD"": ""No special equipment needed"",
                          ""correctAnswer"": ""B""
                        }
                      ]
                    }
                       
                    TRAINING MATERIALS:
                    <%documentContent%>

                    Generate the quiz based on the above training materials and return only valid JSON with no markdown formatting.
                    ";

                if (primerPromptSetting == null)
                {
                    primerPromptSetting = new GlobalSetting
                    {
                        UserId = Guid.Empty.ToString(),
                        Category = "Algorithm",
                        Key = "PrimerPrompt",
                        Value = defaultPrimerPrompt,
                        IsEncrypted = false,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };
                    await _context.GlobalSettings.AddAsync(primerPromptSetting);
                    await _context.SaveChangesAsync();
                }

                if (quizPromptSetting == null)
                {
                    quizPromptSetting = new GlobalSetting
                    {
                        UserId = Guid.Empty.ToString(),
                        Category = "Algorithm",
                        Key = "QuizPrompt",
                        Value = defaultQuizPrompt,
                        IsEncrypted = false,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };
                    await _context.GlobalSettings.AddAsync(quizPromptSetting);
                    await _context.SaveChangesAsync();
                }

                var response = new
                {
                    primerPrompt = primerPromptSetting?.Value ?? defaultPrimerPrompt,
                    quizPrompt = quizPromptSetting?.Value ?? defaultQuizPrompt,
                    version = 1,
                    organizationId = organizationId
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal server error", error = ex.Message });
            }
        }

        [HttpPut("algorithm-settings")]
        public async Task<IActionResult> SaveAlgorithmSettings([FromBody] SaveAlgorithmSettingsRequest request)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();
            if (request == null)
                return BadRequest("Request body is required");
            try
            {
                // Get user's organization
                var userGroup = await GetUserGroup(userId);
                var organizationId = userGroup?.Name ?? "default";
                // Update or create primer prompt setting
                var primerPromptSetting = await _context.GlobalSettings
                    .Where(gs => gs.UserId == Guid.Empty.ToString() &&
                                gs.Category == "Algorithm" &&
                                gs.Key == "PrimerPrompt")
                    .FirstOrDefaultAsync();
                if (primerPromptSetting != null)
                {
                    primerPromptSetting.Value = request.PrimerPrompt;
                    primerPromptSetting.UpdatedAt = DateTime.UtcNow;
                    _context.GlobalSettings.Update(primerPromptSetting);
                }
                else
                {
                    primerPromptSetting = new GlobalSetting
                    {
                        UserId = Guid.Empty.ToString(),
                        Category = "Algorithm",
                        Key = "PrimerPrompt",
                        Value = request.PrimerPrompt,
                        IsEncrypted = false,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };
                    await _context.GlobalSettings.AddAsync(primerPromptSetting);
                }
                // Update or create quiz prompt setting
                var quizPromptSetting = await _context.GlobalSettings
                    .Where(gs => gs.UserId == Guid.Empty.ToString() &&
                                gs.Category == "Algorithm" &&
                                gs.Key == "QuizPrompt")
                    .FirstOrDefaultAsync();
                if (quizPromptSetting != null)
                {
                    quizPromptSetting.Value = request.QuizPrompt;
                    quizPromptSetting.UpdatedAt = DateTime.UtcNow;
                    _context.GlobalSettings.Update(quizPromptSetting);
                }
                else
                {
                    quizPromptSetting = new GlobalSetting
                    {
                        UserId = Guid.Empty.ToString(),
                        Category = "Algorithm",
                        Key = "QuizPrompt",
                        Value = request.QuizPrompt,
                        IsEncrypted = false,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };
                    await _context.GlobalSettings.AddAsync(quizPromptSetting);
                }
                // Save all changes to database
                await _context.SaveChangesAsync();

                // Return the updated settings
                var response = new
                {
                    success = true,
                    message = "Algorithm settings saved successfully",
                    primerPrompt = request.PrimerPrompt,
                    quizPrompt = request.QuizPrompt,
                    //version = await GetSettingsVersion(userId),
                    organizationId = organizationId,
                    updatedAt = DateTime.UtcNow
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    success = false,
                    message = "Failed to save algorithm settings",
                    error = ex.Message
                });
            }
        }

        // ===== HELPER METHODS =====
        private async Task<UserGroup?> GetUserGroup(string? userId)
        {
            if (string.IsNullOrEmpty(userId)) return null;

            return await _context.UserGroups
                        .Where(ug => ug.Users.Any(u => u.Id == userId))
                        .FirstOrDefaultAsync();
        }

        private async Task<bool> HasProjectAccess(int projectId, string? userId)
        {
            if (string.IsNullOrEmpty(userId)) return false;

            var userGroup = await GetUserGroup(userId);
            return await _context.Projects
                        .AnyAsync(p => p.Id == projectId && 
                                     (p.UserId == userId || (userGroup != null && p.GroupId == userGroup.Id)));
        }

        private static string GetProcessingStatus(int assetId)
        {
            // AssetProcessingStatus table not implemented yet
            // Return default status for now
            return "uploaded";
        }

        private static string GetFileType(string fileName)
        {
            var extension = Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".pdf" => "PDF",
                ".docx" => "Word",
                ".pptx" => "PowerPoint",
                ".xlsx" => "Excel",
                _ => "Document"
            };
        }

        private async Task<object> CreatePrimerAsset_new(ApplicationDbContext context, string htmlContent, GeneratePrimerRequest request, string language, string groupName, string userId)
        {
            // Create file
            var dateTime = DateTime.Now.ToString("MMddyy-hhmmss-tt");
            var version = "V1";
            var fileName = $"{request.PrimerName}-{request.ReadingLevel}-{language}-{version}-{dateTime}.html".Replace(" ", "");
            var filePath = Path.Combine("Uploads", groupName, request.ProjectId.ToString(), fileName);
            var fullPath = Path.Combine(_env.WebRootPath, filePath);

            // Ensure directory exists
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);

            // Create HTML content with proper formatting
            // Use the raw HTML content directly
            await System.IO.File.WriteAllTextAsync(fullPath, htmlContent);

            var defaultPrimer = new ProjectPrimer
            {
                ProjectId = request.ProjectId,
                Name = request.PrimerName,
                Description = "Primary training content",
                ReadingLevel = request.ReadingLevel,
                TargetLanguages = language,
                Status = "Generated",
                CreatedBy = userId!,
                ModifiedBy = userId!
            };
            //await _context.ProjectPrimers.AddAsync(defaultPrimer);

            // Create database asset record
            var primerGuidId = Guid.NewGuid().ToString();
            var primerAsset = new Asset
            {
                Name = fileName,
                FilePath = filePath,
                UserId = userId!,
                DateUploaded = DateTime.UtcNow,
                IsActive = true,
                ProjectId = request.ProjectId,
                GuidId = primerGuidId,
                AssetType = "Primer",
                FlowNodeType = "primer",
                FileSize = new FileInfo(fullPath).Length,
                LastModified = DateTime.UtcNow,
                ModifiedBy = userId!,
                ProjectPrimer = defaultPrimer
            };

            await context.Assets.AddAsync(primerAsset);


            return new
            {
                id = primerAsset.GuidId,
                filename = primerAsset.Name,
                title = request.PrimerName,
                fileType = "html",
                filePath = primerAsset.FilePath,
                fileSize = primerAsset.FileSize,
                projectId = primerAsset.ProjectId,
                assetType = "generated",
                generatedBy = "ai",
                createdBy = userId
            };
        }

        private async Task<object> CreatePrimerAsset(ApplicationDbContext context, GeneratedPrimerContent content, GeneratePrimerRequest request, string language, string groupName, string userId)
        {
            // Create file
            var dateTime = DateTime.Now.ToString("MMddyy-hhmmss-tt");
            var version = "V1";
            var fileName = $"{request.PrimerName}-{request.ReadingLevel}-{language}-{version}-{dateTime}.html".Replace(" ", "");
            var filePath = Path.Combine("Uploads", groupName, request.ProjectId.ToString(), fileName);
            var fullPath = Path.Combine(_env.WebRootPath, filePath);

            // Ensure directory exists
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);

            // Create HTML content with proper formatting
            var htmlContent = CreatePrimerHTML(content, request.PrimerName, language);
            await System.IO.File.WriteAllTextAsync(fullPath, htmlContent);

            var defaultPrimer = new ProjectPrimer
            {
                ProjectId = request.ProjectId,
                Name = request.PrimerName,
                Description = "Primary training content",
                ReadingLevel = request.ReadingLevel,
                TargetLanguages = language,
                Status = "Generated",
                CreatedBy = userId!,
                ModifiedBy = userId!
            };
            //await _context.ProjectPrimers.AddAsync(defaultPrimer);

            // Create database asset record
            var primerGuidId = Guid.NewGuid().ToString();
            var primerAsset = new Asset
            {
                Name = fileName,
                FilePath = filePath,
                UserId = userId!,
                DateUploaded = DateTime.UtcNow,
                IsActive = true,
                ProjectId = request.ProjectId,
                GuidId = primerGuidId,
                AssetType = "Primer",
                FlowNodeType = "primer",
                FileSize = new FileInfo(fullPath).Length,
                LastModified = DateTime.UtcNow,
                ModifiedBy = userId!,
                ProjectPrimer = defaultPrimer
            };

            await context.Assets.AddAsync(primerAsset);

            
            return new
            {
                id = primerAsset.GuidId,
                filename = primerAsset.Name,
                title = request.PrimerName,
                fileType = "html",
                filePath = primerAsset.FilePath,
                fileSize = primerAsset.FileSize,
                projectId = primerAsset.ProjectId,
                assetType = "generated",
                generatedBy = "ai",
                createdBy = userId
            };
        }

        private async Task<string> TranslatePrimerToLanguage_new(string englishPrimer, string targetLanguage, int readingLevel)
        {
            var translationPrompt = $@"Translate the following HTML content to {GetLanguageName(targetLanguage)} while maintaining {readingLevel}th grade reading level:

                {englishPrimer}

                Return the translated HTML content directly, maintaining all HTML structure and formatting.";

            try
            {
                var translatedContent = await AskChatGpt(translationPrompt);
                return CleanJsonResponse(translatedContent);
            }
            catch (Exception ex)
            {
                throw new Exception("Error from TranslatePrimerToLanguage");
            }
        }

        private async Task<GeneratedPrimerContent> TranslatePrimerToLanguage(GeneratedPrimerContent englishPrimer, string targetLanguage, int readingLevel)
        {
            var schemaExample = System.Text.Json.JsonSerializer.Serialize(new GeneratedPrimerContent
            {
                Title = "Sample title",
                LearningObjectives = new[] { "Objective 1", "Objective 2" },
                Glossary = new[]
                {
                    new GlossaryTerm { Term = "Term1", Definition = "Definition1" }
                },
                Content = "Sample content",
                ReadingLevel = readingLevel,
                Language = GetLanguageName(targetLanguage)
            },
            new JsonSerializerOptions { WriteIndented = true });

            var translationPrompt = $@"Translate the following English primer into {GetLanguageName(targetLanguage)}
            Return the result strictly as **valid JSON** matching this structure:
            
            {schemaExample}

            Here are the details to translate:

            Learning Objectives:
            {string.Join("\n", englishPrimer.LearningObjectives.Select((obj, i) => $"{i + 1}. {obj}"))}

            Glossary Terms:
            {string.Join("\n", englishPrimer.Glossary.Select(g => $"- {g.Term}: {g.Definition}"))}

            Content:
            {englishPrimer.Content}
            ";

            try
            {
                var response = await AskChatGpt(translationPrompt);

                if (string.IsNullOrEmpty(response))
                {
                    throw new Exception($"No response from ChatGPT API for {targetLanguage} translation");
                }

                string cleanedResponse = CleanJsonResponse(response);
                var translatedContent = System.Text.Json.JsonSerializer.Deserialize<GeneratedPrimerContent>(cleanedResponse, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return translatedContent; //?? CreateFallbackContent(englishPrimer.Title, readingLevel, targetLanguage);
            }
            catch (Exception ex)
            {
                return new GeneratedPrimerContent();
                //return CreateFallbackContent(englishPrimer.Title, readingLevel, targetLanguage);
            }
        }

        //private async Task<int> GetSettingsVersion(string userId)
        //{
        //    var settingsCount = await _context.GlobalSettings
        //        .Where(gs => gs.UserId == userId && gs.Category == "Algorithm")
        //        .CountAsync();

        //    return settingsCount > 0 ? settingsCount : 1;
        //}

        private async Task<string> ExtractTextFromPdf(string filePath)
        {
            try
            {
                if (System.IO.File.Exists(filePath))
                {
                    using (var pdf = new PdfDocument(new PdfReader(filePath)))
                    {
                        var text = new StringBuilder();

                        for (int i = 1; i <= pdf.GetNumberOfPages(); i++)
                        {
                            text.Append(PdfTextExtractor.GetTextFromPage(pdf.GetPage(i)));
                        }

                        string extractedText = text.ToString();

                        return extractedText;
                    }
                }
                return "";
            }
            catch
            {
                return "";
            }
        }

        private async Task<string> ExtractTextFromPptx(string filePath)
        {
            try
            {
                if (System.IO.File.Exists(filePath))
                {
                    var text = new StringBuilder();

                    using (var doc = PresentationDocument.Open(filePath, false))
                    {
                        foreach (var slidePart in doc.PresentationPart.SlideParts)
                        {
                            foreach (var paragraph in slidePart.Slide.Descendants<DocumentFormat.OpenXml.Drawing.Paragraph>())
                            {
                                foreach (var run in paragraph.Descendants<DocumentFormat.OpenXml.Drawing.Run>())
                                {
                                    if (run.Text != null)
                                    {
                                        text.Append(run.Text.Text);
                                    }
                                }
                                text.AppendLine();
                            }
                            text.AppendLine("----- End of Slide -----\n");
                        }
                    }

                    return text.ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }
        }

        private async Task<string> ExtractTextFromDocx(string filePath)
        {
            try
            {
                if (System.IO.File.Exists(filePath))
                {
                    var text = new StringBuilder();

                    using (var doc = WordprocessingDocument.Open(filePath, false))
                    {
                        var body = doc.MainDocumentPart.Document.Body;

                        foreach (var paragraph in body.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>())
                        {
                            foreach (var run in paragraph.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>())
                            {
                                if (run.InnerText != null)
                                {
                                    text.Append(run.InnerText);
                                }
                            }
                            text.AppendLine();
                        }
                    }

                    return text.ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }
        }

        private async Task<string> GenerateHealthSafetyPrimer_new(int projectId, int readingLevel, string language,
            string primerName, string documentContent, string customPrompt
        )
        {
            var finalPrompt = customPrompt
                                .Replace("<%readinglevel%>", readingLevel.ToString())
                                .Replace("<%primerName%>", primerName)
                                .Replace("<%documentContent%>", documentContent);

            try
            {
                var response = await AskChatGpt($"{finalPrompt}");

                if (string.IsNullOrEmpty(response))
                {
                    throw new Exception("No response from ChatGPT API");
                }

                // Return the raw AI response directly
                return CleanJsonResponse(response);
            }
            catch (Exception ex)
            {
                // Return fallback HTML content
                throw new Exception("Error from GenerateHealthSafetyPrimer");
            }
        }

        private async Task<GeneratedPrimerContent> GenerateHealthSafetyPrimer(int projectId, int readingLevel, string language,
            string primerName, string documentContent, string customPrompt
        )
        {
            var finalPrompt = customPrompt
                                .Replace("<%readinglevel%>", readingLevel.ToString())
                                .Replace("<%primerName%>", primerName)
                                .Replace("<%documentContent%>", documentContent);

            try
            {
                //var response = await AskChatGpt($"{systemPrompt}\n\nUser Request: {userPrompt}");
                var response = await AskChatGpt($"{finalPrompt}");

                if (string.IsNullOrEmpty(response))
                {
                    throw new Exception("No response from ChatGPT API");
                }

                // Clean the response - remove markdown code blocks and extra formatting
                string cleanedResponse = CleanJsonResponse(response);

                // Parse the JSON response
                var generatedContent = System.Text.Json.JsonSerializer.Deserialize<GeneratedPrimerContent>(cleanedResponse, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return generatedContent;// ?? CreateFallbackContent(primerName, readingLevel, language);
            }
            catch (Exception ex)
            {
                return new GeneratedPrimerContent();
                //return CreateFallbackContent(primerName, readingLevel, language);
            }
        }

        private string GetLanguageName(string languageCode)
        {
            return LanguageMap.ContainsKey(languageCode) ? LanguageMap[languageCode] : languageCode;
        }

        private string ExtractLanguageFromFilename(string filename)
        {
            if (string.IsNullOrEmpty(filename))
                return "en-US";

            filename = filename.ToLower();

            var languagePattern = string.Join("|", LanguageMap.Keys.Select(k => k.ToLower()));

            // Pattern 1: filename-lang-version.html (e.g., "training-8-en-us-v1.html")
            //var match = System.Text.RegularExpressions.Regex.Match(filename, @"-(\d+)-(en-us|fr|es|de|it|pt|zh|ja|ko|vi|th|hi|ru|ar|tr|pl|nl|sv|no|da|fi)-");
            var match = System.Text.RegularExpressions.Regex.Match(filename, $@"-(\d+)-({languagePattern})-");
            if (match.Success)
            {
                return match.Groups[2].Value == "en-us" ? "en-US" : match.Groups[2].Value;
            }

            // Pattern 2: filename-lang.html (e.g., "primer-fr.html")
            //match = System.Text.RegularExpressions.Regex.Match(filename, @"-(en-us|fr|es|de|it|pt|zh|ja|ko|vi|th|hi|ru|ar|tr|pl|nl|sv|no|da|fi)\.html$");
            match = System.Text.RegularExpressions.Regex.Match(filename, $@"-({languagePattern})\.html$");
            if (match.Success)
            {
                return match.Groups[1].Value == "en-us" ? "en-US" : match.Groups[1].Value;
            }

            // Pattern 3: filename_lang.html (e.g., "primer_fr.html")
            //match = System.Text.RegularExpressions.Regex.Match(filename, @"_(en-us|fr|es|de|it|pt|zh|ja|ko|vi|th|hi|ru|ar|tr|pl|nl|sv|no|da|fi)\.html$");
            match = System.Text.RegularExpressions.Regex.Match(filename, $@"_({languagePattern})\.html$");
            if (match.Success)
            {
                return match.Groups[1].Value == "en-us" ? "en-US" : match.Groups[1].Value;
            }

            // Pattern 4: Check for language names in filename
            //if (filename.Contains("french") || filename.Contains("francais"))
            //    return "fr";
            //if (filename.Contains("spanish") || filename.Contains("espanol"))
            //    return "es";
            //if (filename.Contains("german") || filename.Contains("deutsch"))
            //    return "de";
            //if (filename.Contains("italian") || filename.Contains("italiano"))
            //    return "it";

            // Default to English if no language detected
            return "en-US";
        }

        private async Task<string> AskChatGpt(string prompt)
        {
            using var scope = _scopeFactory.CreateScope();
            var httpClientFactory = scope.ServiceProvider.GetRequiredService<IHttpClientFactory>();
            var httpClient = httpClientFactory.CreateClient();
            httpClient.Timeout = TimeSpan.FromMinutes(5); // extend timeout

            string apiKey = _aISettings.ChatgptApiKey;

            var requestBody = new
            {
                model = "gpt-4-turbo",
                messages = new[]
                {
                    new { role = "user", content = prompt }
                },
                temperature = 0.7
            };

            var json = Newtonsoft.Json.JsonConvert.SerializeObject(requestBody);

            var httpRequest = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri("https://api.openai.com/v1/chat/completions"),
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };

            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            var response = await httpClient.SendAsync(httpRequest);
            var responseText = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var parsed = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(responseText);
            string reply = parsed?.choices?[0]?.message?.content?.ToString();

            return reply ?? "No response received.";
        }

        private string CreatePrimerHTML(GeneratedPrimerContent content, string primerName, string language)
        {
            var html = $@"<!DOCTYPE html>
            <html lang=""{language}"">
            <head>
                <meta charset=""UTF-8"">
                <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }}
                    h1, h2, h3 {{ color: #2c3e50; }}
                    .objectives {{ background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }}
                    .glossary {{ background: #e9ecef; padding: 20px; border-radius: 5px; margin: 20px 0; }}
                    .glossary-term {{ margin-bottom: 10px; }}
                    .term {{ font-weight: bold; color: #495057; }}
                    .definition {{ margin-left: 20px; }}
                </style>
            </head>
            <body>
                <h1>{content.Title}</h1>
                <p><strong>Reading Level:</strong> {content.ReadingLevel}th Grade</p>
                <p><strong>Language:</strong> {content.Language}</p>
    
                <div class=""objectives"">
                    <h2>Learning Objectives</h2>
                    <ul>";

                        foreach (var objective in content.LearningObjectives)
                        {
                            html += $"<li>{objective}</li>";
                        }

                        html += @"</ul>
                </div>
    
                <div class=""glossary"">
                    <h2>Glossary</h2>";

                        foreach (var term in content.Glossary)
                        {
                            html += $@"<div class=""glossary-term"">
                        <div class=""term"">{term.Term}</div>
                        <div class=""definition"">{term.Definition}</div>
                    </div>";
                        }

                        html += $@"</div>
    
                <div class=""content"">
                    {content.Content}
                </div>
            </body>
            </html>";

            return html;
        }

        private GeneratedPrimerContent CreateFallbackContent(string primerName, int readingLevel, string language)
        {
            return new GeneratedPrimerContent
            {
                Title = primerName,
                LearningObjectives = new[]
                {
                    "Understand basic workplace safety protocols",
                    "Identify and use appropriate personal protective equipment",
                    "Recognize common workplace hazards and risks"
                },
                Glossary = new[]
                {
                    new GlossaryTerm { Term = "PPE", Definition = "Personal Protective Equipment used for safety" },
                    new GlossaryTerm { Term = "Hazard", Definition = "Something that can cause harm or danger" }
                },
                Content = $"<h2>{primerName}</h2><p>Comprehensive safety training content would be generated here.</p>",
                ReadingLevel = readingLevel,
                Language = GetLanguageName(language)
            };
        }

        private string CleanJsonResponse(string response)
        {
            if (string.IsNullOrEmpty(response))
                return response;

            // Remove markdown code blocks
            var cleaned = response.Trim();

            // Remove opening code block markers
            if (cleaned.StartsWith("```json"))
                cleaned = cleaned.Substring(7);
            else if (cleaned.StartsWith("```"))
                cleaned = cleaned.Substring(3);

            // Remove closing code block markers
            if (cleaned.EndsWith("```"))
                cleaned = cleaned.Substring(0, cleaned.Length - 3);

            // Remove any leading/trailing whitespace
            cleaned = cleaned.Trim();

            // Find the first { and last } to extract just the JSON
            int firstBrace = cleaned.IndexOf('{');
            int lastBrace = cleaned.LastIndexOf('}');

            if (firstBrace >= 0 && lastBrace > firstBrace)
            {
                cleaned = cleaned.Substring(firstBrace, lastBrace - firstBrace + 1);
            }

            return cleaned;
        }

        private async Task<string> ExtractDocumentContent(Asset asset)
        {
            var documentPath = Path.Combine(_env.WebRootPath, asset.FilePath);
            string textContent = "";
            // Extract text based on file type
            if (asset.Name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase))
            {
                textContent = await ExtractTextFromPdf(documentPath);
            }
            else if (asset.Name.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
            {
                textContent = await System.IO.File.ReadAllTextAsync(documentPath);
            }
            else if (asset.Name.EndsWith(".pptx", StringComparison.OrdinalIgnoreCase))
            {
                textContent = await ExtractTextFromPptx(documentPath);
            }
            else if (asset.Name.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
            {
                textContent = await ExtractTextFromDocx(documentPath);
            }

            return textContent;
        }

        private async Task<QuizData> GenerateQuizWithAI(string userId, ApplicationDbContext context,QuizGenerationParams parameters)
        {
            // This method should call your OpenAI service
            // Implementation depends on your AI service setup

            var prompt = await BuildQuizPrompt(userId, context, parameters);
            var response = await AskChatGpt(prompt);

            try
            {
                return JsonSerializer.Deserialize<QuizData>(response);
            }
            catch (JsonException ex)
            {
                // Return fallback structure
                return new QuizData
                {
                    Title = $"{parameters.PrimerName} Quiz",
                    ReadingLevel = parameters.ReadingLevel,
                    Language = parameters.Language,
                    Questions = new List<QuizBankQuestion>()
                };
            }
        }

        private async Task<string> BuildQuizPrompt(string userId, ApplicationDbContext context, QuizGenerationParams parameters)
        {
            //var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            var documentContent = string.Join("\n\n",
                parameters.DocumentContents.Select(doc => $"=== {doc.Name} ===\n{doc.Content}"));

            var quizPromptSetting = await context.GlobalSettings
                    .Where(gs => gs.UserId == Guid.Empty.ToString() &&
                                gs.Category == "Algorithm" &&
                                gs.Key == "QuizPrompt")
                    .FirstOrDefaultAsync();

            var finalPrompt = quizPromptSetting?.Value
                                .Replace("<%readinglevel%>", parameters.ReadingLevel)
                                .Replace("<%primerName%>", parameters.PrimerName)
                                .Replace("<%documentContent%>", documentContent);

            return finalPrompt;
        }
        
    }
    

    // ===== REQUEST/RESPONSE MODELS =====
    public class CreateProjectRequest
    {
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
    }

    public class CreatePrimerRequest
    {
        public int ProjectId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public int ReadingLevel { get; set; } = 8;
        public string[] TargetLanguages { get; set; } = new[] { "en-US" };
    }

    public class UpdatePrimerRequest
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int? ReadingLevel { get; set; }
        public string[]? TargetLanguages { get; set; }
        public string? Status { get; set; }
    }

    public class GeneratePrimerRequest
    {
        public int ProjectId { get; set; }
        public string PrimerName { get; set; } = string.Empty;
        public int ReadingLevel { get; set; } = 8;
        //public string Language { get; set; } = "en-US";
        //public string[] Language { get; set; } = new[] { "en-US" };
        public string[] Languages { get; set; } = new[] { "en-US" };
        public string DocumentId { get; set; } = string.Empty;
    }

    public class GeneratedPrimerContent
    {
        public string Title { get; set; } = string.Empty;
        public string[] LearningObjectives { get; set; } = Array.Empty<string>();
        public GlossaryTerm[] Glossary { get; set; } = Array.Empty<GlossaryTerm>();
        public string Content { get; set; } = string.Empty;
        public int ReadingLevel { get; set; }
        public string Language { get; set; } = string.Empty;
    }

    public class GlossaryTerm
    {
        public string Term { get; set; } = string.Empty;
        public string Definition { get; set; } = string.Empty;
    }

    public class DocumentUploadRequest
    {
        public int ProjectId { get; set; }
        public string Filename { get; set; } = string.Empty;
        public string OriginalName { get; set; } = string.Empty;
        public string? FileType { get; set; }
        public long FileSize { get; set; }
        public string UploadedBy { get; set; } = string.Empty;
        public string OrganizationId { get; set; } = string.Empty;
    }

    // ===== ADDITIONAL MODEL CLASSES =====
    //public class QuizQuestion
    //{
    //    public int Id { get; set; }
    //    public int ProjectId { get; set; }
    //    public int? PrimerId { get; set; }
    //    public string Question { get; set; } = string.Empty;
    //    public string QuestionType { get; set; } = "MultipleChoice";
    //    public string? Options { get; set; }
    //    public string CorrectAnswer { get; set; } = string.Empty;
    //    public string? Explanation { get; set; }
    //    public string Language { get; set; } = "en-US";
    //    public string Difficulty { get; set; } = "medium";
    //    public string? Category { get; set; }
    //    public int Points { get; set; } = 1;
    //    public string Status { get; set; } = "pending";
    //    public string CreatedBy { get; set; } = string.Empty;
    //    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    //    public DateTime LastModified { get; set; } = DateTime.UtcNow;
    //    public string ModifiedBy { get; set; } = string.Empty;
    //    public bool IsActive { get; set; } = true;
    //}

    public class QuizBankQuestion
    {
        [JsonPropertyName("question")]
        public string Question { get; set; }

        [JsonPropertyName("optionA")]
        public string OptionA { get; set; }

        [JsonPropertyName("optionB")]
        public string OptionB { get; set; }

        [JsonPropertyName("optionC")]
        public string OptionC { get; set; }

        [JsonPropertyName("optionD")]
        public string OptionD { get; set; }

        [JsonPropertyName("correctAnswer")]
        public string CorrectAnswer { get; set; }


        [JsonPropertyName("options")]
        public List<string> Options { get; set; }

        public string Explanation { get; set; }
    }

    public class StudentPortal
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string AccessUrl { get; set; } = string.Empty;
        public string? QrCodePath { get; set; }
        public int MinPassingScore { get; set; } = 70;
        public int? TimeLimit { get; set; }
        public int? MaxAttempts { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsPublished { get; set; } = false;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime LastModified { get; set; } = DateTime.UtcNow;
        public string ModifiedBy { get; set; } = string.Empty;
    }

    public class UpdateProjectRequest
    {
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
    }

    public class UpdateAssetContentRequest
    {
        public string Title { get; set; } = "";
        public string Content { get; set; } = "";
    }

    public class SaveAlgorithmSettingsRequest
    {
        public string PrimerPrompt { get; set; } = string.Empty;
        public string QuizPrompt { get; set; } = string.Empty;
    }

    public class GenerateQuizRequest
    {
        public string PrimerName { get; set; }
        public int ReadingLevel { get; set; }
        public string Language { get; set; }
    }

    public class DocumentContent
    {
        public string Name { get; set; }
        public string Content { get; set; }
    }

    public class QuizData
    {
        [JsonPropertyName("title")]
        public string Title { get; set; }

        [JsonPropertyName("readingLevel")]
        public string ReadingLevel { get; set; }

        [JsonPropertyName("language")]
        public string Language { get; set; }

        [JsonPropertyName("questions")]
        public List<QuizBankQuestion> Questions { get; set; }
    }

    public class QuizGenerationParams
    {
        public string ProjectId { get; set; }
        public string PrimerName { get; set; }
        public string ReadingLevel { get; set; }
        public string Language { get; set; }
        public List<DocumentContent> DocumentContents { get; set; }
    }

    public class QuizFileInfo
    {
        public string Filename { get; set; }
        public string FilePath { get; set; }
        public DateTime CreatedDate { get; set; }
        public long Size { get; set; }
    }

    public class QuizQuestionResponse
    {
        public string Id { get; set; }
        public string Question { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string CorrectAnswer { get; set; }
        public string Language { get; set; }
        public int ReadingLevel { get; set; }
        public string QuizTitle { get; set; }
        public string SourceFile { get; set; }
    }

    public class UpdateQuizRequest
    {
        public object QuizData { get; set; }
    }

    public class JobStatus
    {
        public string Id { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty; // started, processing, completed, failed
        public int Progress { get; set; } = 0; // 0-100
        public string Message { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public object Result { get; set; }
        public string Error { get; set; } = string.Empty;
    }

    public class AssignOrganizationRequest
    {
        public string OrganizationId { get; set; }
    }

    public class UserEnrollmentRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string CellPhone { get; set; }
        public string LandlinePhone { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Country { get; set; } = "United States";

        // Account type flags
        public bool IsPersonalAccount { get; set; }
        public bool IsCompanyAccount { get; set; }
        public bool ReuseContactInfo { get; set; }

        // Company information (optional)
        public string CompanyName { get; set; }
        public string CompanyPhone { get; set; }
        public string PrimaryContactFirstName { get; set; }
        public string PrimaryContactLastName { get; set; }
        public string PrimaryContactEmail { get; set; }
        public string CompanyAddress1 { get; set; }
        public string CompanyAddress2 { get; set; }
        public string CompanyCity { get; set; }
        public string CompanyState { get; set; }
        public string CompanyZipCode { get; set; }
        public string CompanyCountry { get; set; } = "United States";
    }
}