using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace HstCopilot.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? CellPhone { get; set; }
        public string? LandlinePhone { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }
        public string? Country { get; set; } = "United States"; // default

        public DateTime? CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? LastLoginDate { get; set; }

        public virtual ICollection<UserGroup> Groups { get; set; } = new List<UserGroup>();
    }
}