﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using HstCopilot.Data;
using HstCopilot.Models;
using System.Text.Json.Serialization;

namespace HstCopilot.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<AccountController> _logger;
        private readonly HCaptchaSettings _hCaptchaSettings;
        private readonly IWebHostEnvironment _env;

        public AccountController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            IHttpClientFactory httpClientFactory,
            ILogger<AccountController> logger,
            IOptions<HCaptchaSettings> hCaptchaSettings, 
            IWebHostEnvironment env)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _hCaptchaSettings = hCaptchaSettings.Value;
            _env = env;
        }

        [HttpGet]
        public IActionResult Login()
        {
            ViewData["HCaptchaSiteKey"] = string.IsNullOrEmpty(_hCaptchaSettings.SiteKey)
                ? "10000000-ffff-ffff-ffff-000000000001"
                : _hCaptchaSettings.SiteKey;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password, [FromForm(Name = "h-captcha-response")] string h_captcha_response)
        {
            if (!Request.Host.Host.Contains("localhost"))
            {
                //if (string.IsNullOrEmpty(h_captcha_response))
                //{
                //    ModelState.AddModelError("", "Please complete the hCaptcha challenge.");
                //    SetHCaptchaSiteKey();
                //    return View();
                //}

                //var client = _httpClientFactory.CreateClient();
                //var content = new FormUrlEncodedContent(new[]
                //{
                //    new KeyValuePair<string, string>("response", h_captcha_response),
                //    new KeyValuePair<string, string>("secret", _hCaptchaSettings.SecretKey)
                //});
                //var response = await client.PostAsync("https://hcaptcha.com/siteverify", content);
                //var json = await response.Content.ReadAsStringAsync();
                //var captchaResult = JsonSerializer.Deserialize<HCaptchaResponse>(json);

                //if (!captchaResult.Success)
                //{
                //    ModelState.AddModelError("", "Captcha verification failed.");
                //    SetHCaptchaSiteKey();
                //    return View();
                //}
            }
            
            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                ModelState.AddModelError("", "Invalid login attempt.");
                SetHCaptchaSiteKey();
                return View();
            }

            var result = await _signInManager.PasswordSignInAsync(user, password, isPersistent: false, lockoutOnFailure: false);
            if (result.Succeeded)
            {
                if (await _userManager.IsInRoleAsync(user, "Superadmin"))
                {
                    //return RedirectToAction("Dashboard", "Admin");
                    return RedirectToAction("Index", "Iteration1");
                }
                if (await _userManager.IsInRoleAsync(user, "Instructor"))
                {
                    //return RedirectToAction("Dashboard", "Instructor");
                    return RedirectToAction("Index", "Iteration1");
                }
                if (await _userManager.IsInRoleAsync(user, "Pending"))
                {
                    return RedirectToAction("Pending", "Account");
                }
                if (await _userManager.IsInRoleAsync(user, "User")) 
                {
                    return RedirectToAction("Index", "Iteration1");
                }
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Invalid login attempt.");
            SetHCaptchaSiteKey();
            return View();
        }

        [HttpGet]
        public IActionResult Register()
        {
            ViewData["HCaptchaSiteKey"] = string.IsNullOrEmpty(_hCaptchaSettings.SiteKey)
                ? "10000000-ffff-ffff-ffff-000000000001"
                : _hCaptchaSettings.SiteKey;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(string email, string password, [FromForm(Name = "h-captcha-response")] string h_captcha_response)
        {
            if (string.IsNullOrEmpty(h_captcha_response))
            {
                ModelState.AddModelError("", "Please complete the hCaptcha challenge.");
                SetHCaptchaSiteKey();
                return View();
            }

            var client = _httpClientFactory.CreateClient();
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("response", h_captcha_response),
                new KeyValuePair<string, string>("secret", _hCaptchaSettings.SecretKey)
            });
            var response = await client.PostAsync("https://hcaptcha.com/siteverify", content);
            var json = await response.Content.ReadAsStringAsync();
            var captchaResult = JsonSerializer.Deserialize<HCaptchaResponse>(json);

            if (!captchaResult.Success)
            {
                ModelState.AddModelError("", "Captcha verification failed.");
                SetHCaptchaSiteKey();
                return View();
            }

            var user = new ApplicationUser { UserName = email, Email = email };
            var result = await _userManager.CreateAsync(user, password);
            if (result.Succeeded)
            {
                var roleResult = await _userManager.AddToRoleAsync(user, "Pending");
                if (!roleResult.Succeeded)
                {
                    foreach (var error in roleResult.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                    SetHCaptchaSiteKey();
                    return View();
                }

                _logger.LogInformation($"Successfully registered user: {email}");
                await _signInManager.SignInAsync(user, isPersistent: false);
                return RedirectToAction("Pending", "Account");
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
            SetHCaptchaSiteKey();
            return View();
        }

        [HttpGet]
        public IActionResult Pending()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Login");
        }

        private void SetHCaptchaSiteKey()
        {
            ViewData["HCaptchaSiteKey"] = string.IsNullOrEmpty(_hCaptchaSettings.SiteKey)
                ? "10000000-ffff-ffff-ffff-000000000001"
                : _hCaptchaSettings.SiteKey;
        }
    }

    public class HCaptchaResponse
    {
        [JsonPropertyName("success")]
        public bool Success { get; set; }
    }
}