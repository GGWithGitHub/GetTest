﻿using HstCopilot.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace HstCopilot.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, IdentityRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<WorkflowProject> WorkflowProjects { get; set; }
        public DbSet<WorkflowVersion> WorkflowVersions { get; set; }
        public DbSet<WorkflowService> WorkflowServices { get; set; }
        public DbSet<XApiStatement> xapi_statements { get; set; }
        public DbSet<XApiState> xapi_state { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<Asset> Assets { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<AssetProcessingStatus> AssetsProcessingStatus { get; set; }
        public DbSet<Language> Languages { get; set; }
        public DbSet<ProjectLanguage> ProjectLanguages { get; set; }
        public DbSet<ReadingLevel> ReadingLevels { get; set; }
        public DbSet<ProjectReadingLevel> ProjectReadingLevels { get; set; }

        public DbSet<DecisionCategory> DecisionCategories { get; set; }
        public DbSet<DecisionEntry> DecisionEntries { get; set; }
        public DbSet<DecisionThread> DecisionThreads { get; set; }
        public DbSet<DecisionMetadata> DecisionMetadata { get; set; }
        public DbSet<DecisionEvidence> DecisionEvidence { get; set; }
        public DbSet<DecisionProject> DecisionProjects { get; set; } // DbSet name remains plural



        // TLA Sandbox DbSets
        public DbSet<Flow> Flows { get; set; }
        public DbSet<FlowNode> FlowNodes { get; set; }
        public DbSet<FlowConnection> FlowConnections { get; set; }

        public DbSet<GlobalSetting> GlobalSettings { get; set; }

        public DbSet<ProjectPrimer> ProjectPrimers { get; set; }
        public DbSet<QuizQuestion> QuizQuestions { get; set; }
        public DbSet<StudentPortal> StudentPortals { get; set; }
        public DbSet<CertificateTemplate> CertificateTemplates { get; set; }
        public DbSet<StudentSession> StudentSessions { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder); // Call base configuration first

            // Disable migrations for xapi_tables since they are managed manually in SQL
            builder.Entity<XApiStatement>().ToTable("xapi_statements", t => t.ExcludeFromMigrations());
            builder.Entity<XApiState>().ToTable("xapi_state", t => t.ExcludeFromMigrations());

            builder.Entity<XApiStatement>().Property(s => s.ResultScore).HasColumnType("decimal(5,2)");
            builder.Entity<XApiStatement>().HasIndex(s => s.Timestamp);
            builder.Entity<XApiState>().HasIndex(s => new { s.ActivityId, s.StateKey });

            // Configure table names to match SQL schema
            builder.Entity<DecisionEntry>().ToTable("DecisionEntry");
            builder.Entity<DecisionThread>().ToTable("DecisionThread");
            builder.Entity<DecisionCategory>().ToTable("DecisionCategory");
            builder.Entity<DecisionMetadata>().ToTable("DecisionMetadata");
            builder.Entity<DecisionEvidence>().ToTable("DecisionEvidence");
            builder.Entity<DecisionProject>().ToTable("DecisionProject"); // Explicitly map to singular table name

            // Configure the one-to-many relationship between DecisionEntry and DecisionThread
            builder.Entity<DecisionEntry>()
                .HasMany(e => e.ChildThreads)
                .WithOne(t => t.ParentEntry)
                .HasForeignKey(t => t.ParentEntryId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<DecisionThread>()
                .HasOne(t => t.ChildEntry)
                .WithMany()
                .HasForeignKey(t => t.ChildEntryId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure DecisionProject and DecisionEntry relationship
            builder.Entity<DecisionProject>()
                .HasMany(dp => dp.DecisionEntries)
                .WithOne(de => de.Project)
                .HasForeignKey(de => de.ProjectId)
                .OnDelete(DeleteBehavior.Cascade);

            // Existing configurations
            builder.Entity<IdentityRole>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("nvarchar(450)");
                entity.Property(e => e.Name).HasMaxLength(256);
                entity.Property(e => e.NormalizedName).HasMaxLength(256);
                entity.Property(e => e.ConcurrencyStamp).HasMaxLength(256);
            });

            builder.Entity<ApplicationUser>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("nvarchar(450)");
            });

            builder.Entity<UserGroup>(entity =>
            {
                entity.ToTable("AspNetUserGroups");
                entity.Property(e => e.Id).HasColumnType("nvarchar(150)");
                entity.Property(e => e.Name).HasMaxLength(256);
                entity.Property(e => e.NormalizedName).HasMaxLength(256);
            });

            builder.Entity<ApplicationUser>()
                .HasMany(u => u.Groups)
                .WithMany(g => g.Users)
                .UsingEntity<Dictionary<string, object>>(
                    "AspNetUserGroupMembers",
                    j => j.HasOne<UserGroup>().WithMany().HasForeignKey("GroupId").OnDelete(DeleteBehavior.Cascade),
                    j => j.HasOne<ApplicationUser>().WithMany().HasForeignKey("UserId").OnDelete(DeleteBehavior.Cascade),
                    j =>
                    {
                        j.HasKey("UserId", "GroupId");
                        j.ToTable("AspNetUserGroupMembers");
                    });

            builder.Entity<Project>()
                .HasOne(p => p.User)
                .WithMany()
                .HasForeignKey(p => p.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<Project>()
                .HasOne(p => p.Group)
                .WithMany(g => g.Projects)
                .HasForeignKey(p => p.GroupId)
                .OnDelete(DeleteBehavior.SetNull);

            builder.Entity<Asset>()
                .HasOne(a => a.Project)
                .WithMany(p => p.Assets)
                .HasForeignKey(a => a.ProjectId)
                .OnDelete(DeleteBehavior.Cascade);
            builder.Entity<Asset>()
                .ToTable(tb => tb.UseSqlOutputClause(false));


            builder.Entity<Asset>()
                .HasOne(a => a.User)
                .WithMany()
                .HasForeignKey(a => a.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<AssetProcessingStatus>()
                .ToTable("AssetProcessingStatus")
                .HasOne(aps => aps.Asset)
                .WithMany()
                .HasForeignKey(aps => aps.AssetId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<ProjectLanguage>(entity =>
            {
                entity.ToTable("Project_Languages");

                entity.HasKey(pl => new { pl.ProjectId, pl.LanguageId });

                entity.HasOne(pl => pl.Project)
                      .WithMany(p => p.ProjectLanguages)
                      .HasForeignKey(pl => pl.ProjectId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(pl => pl.Language)
                      .WithMany(l => l.ProjectLanguages)
                      .HasForeignKey(pl => pl.LanguageId)
                      .OnDelete(DeleteBehavior.NoAction);
            });

            builder.Entity<ProjectReadingLevel>(entity =>
            {
                entity.ToTable("Project_ReadingLevels");

                entity.HasKey(prl => prl.ProjectId);
                entity.HasOne(prl => prl.Project)
                      .WithMany(p => p.ProjectReadingLevels)
                      .HasForeignKey(prl => prl.ProjectId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(prl => prl.ReadingLevel)
                      .WithMany(rl => rl.ProjectReadingLevels)
                      .HasForeignKey(prl => prl.ReadingLevelId);
            });

            builder.Entity<GlobalSetting>(entity =>
            {
                entity.HasIndex(e => new { e.UserId, e.Category, e.Key })
                      .IsUnique();

                entity.HasOne(e => e.User)
                      .WithMany()
                      .HasForeignKey(e => e.UserId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}