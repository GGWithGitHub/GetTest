﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HstCopilot.Models
{
    public class UserGroup
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString();
        public string? Name { get; set; }
        public string? NormalizedName { get; set; }
        public string? Phone { get; set; }
        public string? PrimaryContactFirstName { get; set; }
        public string? PrimaryContactLastName { get; set; }
        public string? PrimaryContactEmail { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }
        public string? Country { get; set; } = "United States";
        public DateTime? CreatedAt { get; set; } = DateTime.Now;

        public virtual ICollection<ApplicationUser> Users { get; set; } = new List<ApplicationUser>();
        public virtual ICollection<Project> Projects { get; set; } = new List<Project>();
    }
}